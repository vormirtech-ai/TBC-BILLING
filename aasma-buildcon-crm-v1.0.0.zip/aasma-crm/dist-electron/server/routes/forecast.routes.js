"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.forecastRouter = void 0;
const express_1 = require("express");
const errors_1 = require("../lib/errors");
const prisma_1 = require("../lib/prisma");
const forecast_service_1 = require("../services/forecast.service");
exports.forecastRouter = (0, express_1.Router)();
exports.forecastRouter.get('/', (0, errors_1.asyncHandler)(async (_req, res) => {
    res.json(await (0, forecast_service_1.buildAllForecasts)());
}));
exports.forecastRouter.get('/:projectId', (0, errors_1.asyncHandler)(async (req, res) => {
    const forecast = await (0, forecast_service_1.buildForecast)(Number(req.params.projectId));
    if (!forecast)
        throw (0, errors_1.notFound)('Project');
    res.json(forecast);
}));
/** Stores today's forecast so the trend chart has a data point. */
exports.forecastRouter.post('/:projectId/snapshot', (0, errors_1.asyncHandler)(async (req, res) => {
    const forecast = await (0, forecast_service_1.buildForecast)(Number(req.params.projectId));
    if (!forecast)
        throw (0, errors_1.notFound)('Project');
    await (0, forecast_service_1.saveForecastSnapshot)(forecast);
    res.status(201).json(forecast);
}));
exports.forecastRouter.get('/:projectId/snapshots', (0, errors_1.asyncHandler)(async (req, res) => {
    const rows = await prisma_1.prisma.forecastSnapshot.findMany({
        where: { projectId: Number(req.params.projectId) },
        orderBy: { runOn: 'asc' },
        take: 365,
    });
    res.json(rows);
}));
//# sourceMappingURL=forecast.routes.js.map