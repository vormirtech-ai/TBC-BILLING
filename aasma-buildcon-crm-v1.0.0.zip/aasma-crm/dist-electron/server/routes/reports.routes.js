"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.reportsRouter = void 0;
const express_1 = require("express");
const errors_1 = require("../lib/errors");
const query_1 = require("../lib/query");
const settings_1 = require("../lib/settings");
const activity_1 = require("../lib/activity");
const report_service_1 = require("../services/report.service");
const excel_service_1 = require("../services/excel.service");
exports.reportsRouter = (0, express_1.Router)();
exports.reportsRouter.get('/', (0, errors_1.asyncHandler)(async (_req, res) => {
    res.json(report_service_1.REPORTS);
}));
exports.reportsRouter.get('/:key', (0, errors_1.asyncHandler)(async (req, res) => {
    const key = String(req.params.key);
    if (!report_service_1.REPORTS.some((report) => report.key === key))
        throw (0, errors_1.badRequest)('Unknown report.');
    res.json(await (0, report_service_1.buildReport)(key, (0, query_1.parseListQuery)(req)));
}));
/** Same data as the on-screen report, delivered as a formatted workbook. */
exports.reportsRouter.get('/:key/export', (0, errors_1.asyncHandler)(async (req, res) => {
    const key = String(req.params.key);
    if (!report_service_1.REPORTS.some((report) => report.key === key))
        throw (0, errors_1.badRequest)('Unknown report.');
    const report = await (0, report_service_1.buildReport)(key, (0, query_1.parseListQuery)(req));
    const settings = await (0, settings_1.getSettings)();
    const workbook = await (0, excel_service_1.reportToWorkbook)(report, settings);
    const buffer = await (0, excel_service_1.workbookBuffer)(workbook);
    const fileName = (0, excel_service_1.reportFileName)(report);
    await (0, activity_1.logActivity)({
        actor: req.user?.username ?? 'system',
        action: 'EXPORT',
        entity: 'Report',
        entityId: key,
        detail: `${report.rows.length} row(s)`,
    });
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
    res.setHeader('Content-Length', String(buffer.length));
    res.end(buffer);
}));
//# sourceMappingURL=reports.routes.js.map