"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.propertiesRouter = void 0;
const express_1 = require("express");
const prisma_1 = require("../lib/prisma");
const errors_1 = require("../lib/errors");
const crud_1 = require("../lib/crud");
const activity_1 = require("../lib/activity");
const query_1 = require("../lib/query");
const schemas_1 = require("../../shared/schemas");
exports.propertiesRouter = (0, express_1.Router)();
const listInclude = {
    project: { select: { id: true, name: true, code: true } },
    bookings: {
        where: { status: 'ACTIVE' },
        select: { id: true, client: { select: { id: true, name: true } } },
    },
};
/**
 * Tower → floor → unit grid used by the property map. Returns every unit for a
 * project in one call so the map renders without further requests.
 */
exports.propertiesRouter.get('/map', (0, errors_1.asyncHandler)(async (req, res) => {
    const projectId = req.query.projectId ? Number(req.query.projectId) : undefined;
    const properties = await prisma_1.prisma.property.findMany({
        where: projectId ? { projectId } : {},
        include: { bookings: { where: { status: 'ACTIVE' }, select: { client: { select: { name: true } } } } },
        orderBy: [{ tower: 'asc' }, { floor: 'desc' }, { unit: 'asc' }],
    });
    const towers = new Map();
    for (const property of properties) {
        const floors = towers.get(property.tower) ?? new Map();
        const units = floors.get(property.floor) ?? [];
        units.push(property);
        floors.set(property.floor, units);
        towers.set(property.tower, floors);
    }
    res.json(Array.from(towers.entries()).map(([tower, floors]) => ({
        tower,
        floors: Array.from(floors.entries())
            .sort((a, b) => b[0] - a[0])
            .map(([floor, units]) => ({
            floor,
            units: units.map((unit) => ({
                id: unit.id,
                unit: unit.unit,
                unitType: unit.unitType,
                sizeSqft: unit.sizeSqft,
                price: unit.price,
                facing: unit.facing,
                status: unit.status,
                client: unit.bookings[0]?.client?.name ?? null,
            })),
        })),
    })));
}));
exports.propertiesRouter.get('/summary', (0, errors_1.asyncHandler)(async (req, res) => {
    const projectId = req.query.projectId ? Number(req.query.projectId) : undefined;
    const where = projectId ? { projectId } : {};
    const [byStatus, value] = await Promise.all([
        prisma_1.prisma.property.groupBy({ by: ['status'], where, _count: { _all: true }, _sum: { price: true } }),
        prisma_1.prisma.property.aggregate({ where, _sum: { price: true, sizeSqft: true }, _count: { _all: true } }),
    ]);
    res.json({
        byStatus: byStatus.map((row) => ({
            status: row.status,
            count: row._count._all,
            value: row._sum.price ?? 0,
        })),
        total: value._count._all,
        totalValue: value._sum.price ?? 0,
        totalArea: value._sum.sizeSqft ?? 0,
    });
}));
/** Bulk import from the Properties screen (parsed from a pasted sheet). */
exports.propertiesRouter.post('/import', (0, errors_1.asyncHandler)(async (req, res) => {
    const { rows } = schemas_1.propertyImportSchema.parse(req.body);
    let created = 0;
    let updated = 0;
    for (const row of rows) {
        const existing = await prisma_1.prisma.property.findFirst({
            where: { projectId: row.projectId, tower: row.tower, unit: row.unit },
        });
        if (existing) {
            await prisma_1.prisma.property.update({ where: { id: existing.id }, data: row });
            updated += 1;
        }
        else {
            await prisma_1.prisma.property.create({ data: row });
            created += 1;
        }
    }
    await (0, activity_1.logActivity)({
        actor: req.user?.username ?? 'system',
        action: 'IMPORT',
        entity: 'Property',
        detail: `${created} created, ${updated} updated`,
    });
    res.status(201).json({ created, updated });
}));
exports.propertiesRouter.use((0, crud_1.crudRouter)({
    delegate: prisma_1.prisma.property,
    entity: 'Property',
    schema: schemas_1.propertySchema,
    searchFields: ['tower', 'unit', 'unitType', 'notes'],
    sortable: ['tower', 'floor', 'unit', 'price', 'sizeSqft', 'status', 'createdAt'],
    defaultSort: 'tower',
    listInclude,
    filters: (query) => (0, query_1.combine)(query.projectId ? { projectId: query.projectId } : null, query.status ? { status: query.status } : null),
}));
//# sourceMappingURL=properties.routes.js.map