"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.backupRouter = void 0;
const node_os_1 = __importDefault(require("node:os"));
const node_path_1 = __importDefault(require("node:path"));
const express_1 = require("express");
const multer_1 = __importDefault(require("multer"));
const errors_1 = require("../lib/errors");
const auth_1 = require("../lib/auth");
const activity_1 = require("../lib/activity");
const paths_1 = require("../lib/paths");
const backup_service_1 = require("../services/backup.service");
exports.backupRouter = (0, express_1.Router)();
const upload = (0, multer_1.default)({ dest: node_os_1.default.tmpdir(), limits: { fileSize: 512 * 1024 * 1024 } });
exports.backupRouter.get('/', (0, errors_1.asyncHandler)(async (_req, res) => {
    res.json({ folder: paths_1.PATHS.backupsDir, files: (0, backup_service_1.listBackups)() });
}));
exports.backupRouter.post('/', (0, errors_1.asyncHandler)(async (req, res) => {
    const file = await (0, backup_service_1.createBackup)();
    await (0, activity_1.logActivity)({ actor: req.user?.username ?? 'system', action: 'BACKUP', entity: 'Database', detail: file.name });
    res.status(201).json(file);
}));
exports.backupRouter.get('/:name/download', (0, errors_1.asyncHandler)(async (req, res) => {
    const file = (0, backup_service_1.backupPath)(String(req.params.name));
    res.download(file, node_path_1.default.basename(file));
}));
exports.backupRouter.post('/upload', (0, auth_1.requireRole)('ADMIN'), upload.single('backup'), (0, errors_1.asyncHandler)(async (req, res) => {
    if (!req.file)
        throw (0, errors_1.badRequest)('Choose a .db backup file to upload.');
    const file = (0, backup_service_1.importBackupFile)(req.file.path, req.file.originalname);
    res.status(201).json(file);
}));
/**
 * Restoring swaps the live database file. The client is told to restart, which
 * Electron does for it — a running Prisma client would otherwise still be
 * holding the old file handle.
 */
exports.backupRouter.post('/:name/restore', (0, auth_1.requireRole)('ADMIN'), (0, errors_1.asyncHandler)(async (req, res) => {
    const result = await (0, backup_service_1.restoreBackup)(String(req.params.name));
    await (0, activity_1.logActivity)({
        actor: req.user?.username ?? 'system',
        action: 'RESTORE',
        entity: 'Database',
        detail: result.restoredFrom,
    });
    res.json({ ...result, restartRequired: true });
}));
exports.backupRouter.delete('/:name', (0, auth_1.requireRole)('ADMIN'), (0, errors_1.asyncHandler)(async (req, res) => {
    (0, backup_service_1.deleteBackup)(String(req.params.name));
    res.json({ ok: true });
}));
//# sourceMappingURL=backup.routes.js.map