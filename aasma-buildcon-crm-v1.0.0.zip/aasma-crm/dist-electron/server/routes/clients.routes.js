"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.paymentsRouter = exports.bookingsRouter = exports.clientsRouter = void 0;
const express_1 = require("express");
const prisma_1 = require("../lib/prisma");
const errors_1 = require("../lib/errors");
const crud_1 = require("../lib/crud");
const query_1 = require("../lib/query");
const schemas_1 = require("../../shared/schemas");
exports.clientsRouter = (0, express_1.Router)();
const listInclude = {
    bookings: {
        include: { property: { select: { tower: true, unit: true, projectId: true } } },
    },
    payments: { select: { amount: true } },
};
/**
 * Everything the client detail screen shows: bookings, payments, documents and
 * a single merged timeline of every interaction.
 */
exports.clientsRouter.get('/:id/timeline', (0, errors_1.asyncHandler)(async (req, res) => {
    const clientId = Number(req.params.id);
    const client = await prisma_1.prisma.client.findUnique({ where: { id: clientId } });
    if (!client)
        throw (0, errors_1.notFound)('Client');
    const [interactions, payments, bookings, documents] = await Promise.all([
        prisma_1.prisma.interaction.findMany({ where: { clientId }, orderBy: { happenedOn: 'desc' } }),
        prisma_1.prisma.payment.findMany({ where: { clientId }, orderBy: { paidOn: 'desc' } }),
        prisma_1.prisma.booking.findMany({
            where: { clientId },
            include: { property: { select: { tower: true, unit: true } }, project: { select: { name: true } } },
            orderBy: { bookingDate: 'desc' },
        }),
        prisma_1.prisma.document.findMany({ where: { clientId }, orderBy: { uploadedAt: 'desc' } }),
    ]);
    const timeline = [
        ...interactions.map((row) => ({
            at: row.happenedOn.toISOString(),
            type: row.type,
            title: row.type === 'NOTE' ? 'Note added' : `${row.type} logged`,
            detail: row.detail,
        })),
        ...payments.map((row) => ({
            at: row.paidOn.toISOString(),
            type: 'PAYMENT',
            title: `Payment received (${row.mode})`,
            detail: `${(0, query_1.round)(row.amount, 2)}${row.reference ? ` • ${row.reference}` : ''}`,
        })),
        ...bookings.map((row) => ({
            at: row.bookingDate.toISOString(),
            type: 'BOOKING',
            title: `Booked ${row.property?.tower ?? ''}-${row.property?.unit ?? ''}`,
            detail: `${row.project?.name ?? ''} • agreement value ${(0, query_1.round)(row.agreementValue, 2)}`,
        })),
        ...documents.map((row) => ({
            at: row.uploadedAt.toISOString(),
            type: 'DOCUMENT',
            title: `Document: ${row.title}`,
            detail: row.category,
        })),
    ].sort((a, b) => b.at.localeCompare(a.at));
    const agreementValue = bookings
        .filter((booking) => booking.status !== 'CANCELLED')
        .reduce((acc, booking) => acc + booking.agreementValue, 0);
    const collected = payments.reduce((acc, payment) => acc + payment.amount, 0);
    res.json({
        client,
        bookings,
        payments,
        documents,
        timeline,
        totals: {
            agreementValue: (0, query_1.round)(agreementValue, 2),
            collected: (0, query_1.round)(collected, 2),
            outstanding: (0, query_1.round)(agreementValue - collected, 2),
        },
    });
}));
exports.clientsRouter.post('/:id/interactions', (0, errors_1.asyncHandler)(async (req, res) => {
    const clientId = Number(req.params.id);
    const input = schemas_1.interactionSchema.parse({ ...req.body, clientId });
    const row = await prisma_1.prisma.interaction.create({ data: input });
    res.status(201).json(row);
}));
exports.clientsRouter.use((0, crud_1.crudRouter)({
    delegate: prisma_1.prisma.client,
    entity: 'Client',
    schema: schemas_1.clientSchema,
    searchFields: ['name', 'phone', 'email', 'panNo'],
    sortable: ['createdAt', 'name'],
    defaultSort: 'createdAt',
    dateField: 'createdAt',
    listInclude,
}));
// ------------------------------------------------------------------ bookings
exports.bookingsRouter = (0, express_1.Router)();
exports.bookingsRouter.use((0, crud_1.crudRouter)({
    delegate: prisma_1.prisma.booking,
    entity: 'Booking',
    schema: schemas_1.bookingSchema,
    searchFields: ['agreementNo', 'notes'],
    sortable: ['bookingDate', 'agreementValue', 'createdAt'],
    defaultSort: 'bookingDate',
    dateField: 'bookingDate',
    listInclude: {
        client: { select: { id: true, name: true, phone: true } },
        property: { select: { id: true, tower: true, unit: true, unitType: true } },
        project: { select: { id: true, name: true } },
        payments: { select: { amount: true } },
    },
    filters: (query) => (query.clientId ? { clientId: query.clientId } : null),
    /** A booking takes the unit off the market; cancelling puts it back. */
    afterWrite: async (row) => {
        const status = row.status === 'CANCELLED' ? 'AVAILABLE' : 'SOLD';
        await prisma_1.prisma.property.update({ where: { id: row.propertyId }, data: { status } });
        await prisma_1.prisma.interaction.create({
            data: {
                clientId: row.clientId,
                type: 'NOTE',
                detail: `Booking #${row.id} ${row.status.toLowerCase()}.`,
            },
        });
    },
    beforeDelete: async (id) => {
        const booking = await prisma_1.prisma.booking.findUnique({ where: { id } });
        if (booking) {
            await prisma_1.prisma.property.update({ where: { id: booking.propertyId }, data: { status: 'AVAILABLE' } });
        }
    },
}));
// ------------------------------------------------------------------ payments
exports.paymentsRouter = (0, express_1.Router)();
exports.paymentsRouter.use((0, crud_1.crudRouter)({
    delegate: prisma_1.prisma.payment,
    entity: 'Payment',
    schema: schemas_1.paymentSchema,
    searchFields: ['reference', 'notes'],
    sortable: ['paidOn', 'amount', 'createdAt'],
    defaultSort: 'paidOn',
    dateField: 'paidOn',
    listInclude: {
        client: { select: { id: true, name: true, phone: true } },
        booking: { select: { id: true, agreementNo: true } },
    },
    filters: (query) => (query.clientId ? { clientId: query.clientId } : null),
}));
//# sourceMappingURL=clients.routes.js.map