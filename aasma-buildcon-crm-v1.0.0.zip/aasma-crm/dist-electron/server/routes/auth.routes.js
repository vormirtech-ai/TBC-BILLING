"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.authRouter = void 0;
const express_1 = require("express");
const prisma_1 = require("../lib/prisma");
const errors_1 = require("../lib/errors");
const auth_1 = require("../lib/auth");
const activity_1 = require("../lib/activity");
const schemas_1 = require("../../shared/schemas");
exports.authRouter = (0, express_1.Router)();
/**
 * Local sign-in. There is no remote identity provider: the hash is compared
 * against the row in the local SQLite file and a short-lived token is issued.
 */
exports.authRouter.post('/login', (0, errors_1.asyncHandler)(async (req, res) => {
    const { username, password } = schemas_1.loginSchema.parse(req.body);
    const user = await prisma_1.prisma.user.findUnique({ where: { username: username.toLowerCase() } });
    // Same message either way, so the form cannot be used to discover usernames.
    if (!user || !user.active)
        throw (0, errors_1.unauthorized)('Incorrect username or password.');
    const valid = await (0, auth_1.verifyPassword)(password, user.passwordHash);
    if (!valid)
        throw (0, errors_1.unauthorized)('Incorrect username or password.');
    await prisma_1.prisma.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });
    const authUser = { id: user.id, username: user.username, fullName: user.fullName, role: user.role };
    const token = await (0, auth_1.issueToken)(authUser);
    await (0, activity_1.logActivity)({ actor: user.username, action: 'LOGIN', entity: 'User', entityId: user.id });
    const body = { token, user: authUser };
    res.json(body);
}));
exports.authRouter.get('/me', auth_1.requireAuth, (0, errors_1.asyncHandler)(async (req, res) => {
    res.json(req.user);
}));
exports.authRouter.post('/change-password', auth_1.requireAuth, (0, errors_1.asyncHandler)(async (req, res) => {
    const { currentPassword, newPassword } = schemas_1.changePasswordSchema.parse(req.body);
    const user = await prisma_1.prisma.user.findUnique({ where: { id: req.user.id } });
    if (!user)
        throw (0, errors_1.unauthorized)();
    const valid = await (0, auth_1.verifyPassword)(currentPassword, user.passwordHash);
    if (!valid)
        throw (0, errors_1.unauthorized)('Your current password is not correct.');
    await prisma_1.prisma.user.update({
        where: { id: user.id },
        data: { passwordHash: await (0, auth_1.hashPassword)(newPassword) },
    });
    await (0, activity_1.logActivity)({ actor: user.username, action: 'CHANGE_PASSWORD', entity: 'User', entityId: user.id });
    res.json({ ok: true });
}));
//# sourceMappingURL=auth.routes.js.map