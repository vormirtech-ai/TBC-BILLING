"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.dprRouter = void 0;
const node_fs_1 = __importDefault(require("node:fs"));
const node_path_1 = __importDefault(require("node:path"));
const express_1 = require("express");
const multer_1 = __importDefault(require("multer"));
const prisma_1 = require("../lib/prisma");
const errors_1 = require("../lib/errors");
const activity_1 = require("../lib/activity");
const paths_1 = require("../lib/paths");
const query_1 = require("../lib/query");
const schemas_1 = require("../../shared/schemas");
exports.dprRouter = (0, express_1.Router)();
const include = {
    project: { select: { id: true, name: true, code: true } },
    materials: { include: { material: { select: { id: true, name: true, unit: true } } } },
    photos: true,
};
(0, paths_1.ensureDirectories)();
/** Photos are copied into the local uploads folder — nothing leaves the laptop. */
const upload = (0, multer_1.default)({
    storage: multer_1.default.diskStorage({
        destination: (_req, _file, cb) => cb(null, paths_1.PATHS.uploadsDir),
        filename: (_req, file, cb) => {
            const safe = node_path_1.default.basename(file.originalname).replace(/[^A-Za-z0-9._-]/g, '_');
            cb(null, `${Date.now()}-${safe}`);
        },
    }),
    limits: { fileSize: 12 * 1024 * 1024, files: 10 },
    fileFilter: (_req, file, cb) => {
        const allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
        cb(null, allowed.includes(file.mimetype));
    },
});
exports.dprRouter.get('/', (0, errors_1.asyncHandler)(async (req, res) => {
    const query = (0, query_1.parseListQuery)(req);
    const where = (0, query_1.combine)((0, query_1.searchFilter)(query.q, ['workCompleted', 'siteIssues', 'safetyNotes', 'machinery', 'preparedBy']), (0, query_1.dateFilter)('reportDate', query.from, query.to), query.projectId ? { projectId: query.projectId } : null);
    const [rows, total] = await Promise.all([
        prisma_1.prisma.dpr.findMany({
            where,
            include,
            orderBy: (0, query_1.orderBy)(query, ['reportDate', 'labourCount', 'createdAt'], 'reportDate'),
            ...(0, query_1.paginate)(query),
        }),
        prisma_1.prisma.dpr.count({ where }),
    ]);
    res.json((0, query_1.toPage)(rows, total, query));
}));
exports.dprRouter.get('/:id', (0, errors_1.asyncHandler)(async (req, res) => {
    const row = await prisma_1.prisma.dpr.findUnique({ where: { id: Number(req.params.id) }, include });
    if (!row)
        throw (0, errors_1.notFound)('Daily progress report');
    res.json(row);
}));
/**
 * Creates a DPR. When `deductStock` is set, the materials listed on the report
 * are also issued from inventory, so the site team enters them only once.
 */
exports.dprRouter.post('/', (0, errors_1.asyncHandler)(async (req, res) => {
    const input = schemas_1.dprSchema.parse(req.body);
    const { materials, deductStock, ...rest } = input;
    const created = await prisma_1.prisma.$transaction(async (tx) => {
        const dpr = await tx.dpr.create({
            data: {
                ...rest,
                preparedBy: rest.preparedBy ?? req.user?.fullName ?? null,
                materials: { create: materials.map((item) => ({ materialId: item.materialId, quantity: item.quantity })) },
            },
            include,
        });
        if (deductStock && materials.length > 0) {
            await tx.materialUsage.createMany({
                data: materials.map((item) => ({
                    materialId: item.materialId,
                    projectId: input.projectId,
                    quantity: item.quantity,
                    usedOn: input.reportDate,
                    issuedTo: 'Site (via DPR)',
                    notes: `Auto-issued from DPR #${dpr.id}`,
                })),
            });
        }
        return dpr;
    });
    await (0, activity_1.logActivity)({
        actor: req.user?.username ?? 'system',
        action: 'CREATE',
        entity: 'DPR',
        entityId: created.id,
    });
    res.status(201).json(created);
}));
exports.dprRouter.put('/:id', (0, errors_1.asyncHandler)(async (req, res) => {
    const id = Number(req.params.id);
    const existing = await prisma_1.prisma.dpr.findUnique({ where: { id } });
    if (!existing)
        throw (0, errors_1.notFound)('Daily progress report');
    const input = schemas_1.dprSchema.parse(req.body);
    const { materials, deductStock: _deductStock, ...rest } = input;
    const updated = await prisma_1.prisma.$transaction(async (tx) => {
        // Replacing the material lines is simpler and safer than diffing them.
        await tx.dprMaterial.deleteMany({ where: { dprId: id } });
        return tx.dpr.update({
            where: { id },
            data: {
                ...rest,
                materials: { create: materials.map((item) => ({ materialId: item.materialId, quantity: item.quantity })) },
            },
            include,
        });
    });
    await (0, activity_1.logActivity)({ actor: req.user?.username ?? 'system', action: 'UPDATE', entity: 'DPR', entityId: id });
    res.json(updated);
}));
exports.dprRouter.delete('/:id', (0, errors_1.asyncHandler)(async (req, res) => {
    const id = Number(req.params.id);
    const photos = await prisma_1.prisma.dprPhoto.findMany({ where: { dprId: id } });
    await prisma_1.prisma.dpr.delete({ where: { id } });
    for (const photo of photos) {
        const file = node_path_1.default.join(paths_1.PATHS.uploadsDir, node_path_1.default.basename(photo.filePath));
        if (node_fs_1.default.existsSync(file))
            node_fs_1.default.rmSync(file, { force: true });
    }
    await (0, activity_1.logActivity)({ actor: req.user?.username ?? 'system', action: 'DELETE', entity: 'DPR', entityId: id });
    res.json({ ok: true });
}));
exports.dprRouter.post('/:id/photos', upload.array('photos', 10), (0, errors_1.asyncHandler)(async (req, res) => {
    const dprId = Number(req.params.id);
    const dpr = await prisma_1.prisma.dpr.findUnique({ where: { id: dprId } });
    if (!dpr)
        throw (0, errors_1.notFound)('Daily progress report');
    const files = req.files ?? [];
    if (files.length === 0)
        throw (0, errors_1.badRequest)('Attach at least one image (JPG, PNG, WEBP or GIF, up to 12 MB).');
    const caption = typeof req.body.caption === 'string' ? req.body.caption.slice(0, 200) : null;
    await prisma_1.prisma.dprPhoto.createMany({
        data: files.map((file) => ({ dprId, filePath: file.filename, caption })),
    });
    const photos = await prisma_1.prisma.dprPhoto.findMany({ where: { dprId } });
    res.status(201).json(photos);
}));
exports.dprRouter.delete('/photos/:photoId', (0, errors_1.asyncHandler)(async (req, res) => {
    const photoId = Number(req.params.photoId);
    const photo = await prisma_1.prisma.dprPhoto.findUnique({ where: { id: photoId } });
    if (!photo)
        throw (0, errors_1.notFound)('Photo');
    await prisma_1.prisma.dprPhoto.delete({ where: { id: photoId } });
    const file = node_path_1.default.join(paths_1.PATHS.uploadsDir, node_path_1.default.basename(photo.filePath));
    if (node_fs_1.default.existsSync(file))
        node_fs_1.default.rmSync(file, { force: true });
    res.json({ ok: true });
}));
/** Compact timeline for the DPR screen's left rail. */
exports.dprRouter.get('/timeline/recent', (0, errors_1.asyncHandler)(async (req, res) => {
    const projectId = req.query.projectId ? Number(req.query.projectId) : undefined;
    const rows = await prisma_1.prisma.dpr.findMany({
        where: projectId ? { projectId } : {},
        select: {
            id: true,
            reportDate: true,
            weather: true,
            labourCount: true,
            workCompleted: true,
            project: { select: { name: true } },
            _count: { select: { photos: true, materials: true } },
        },
        orderBy: { reportDate: 'desc' },
        take: 60,
    });
    res.json(rows);
}));
//# sourceMappingURL=dpr.routes.js.map