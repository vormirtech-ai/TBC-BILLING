"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.milestonesRouter = exports.projectsRouter = void 0;
const express_1 = require("express");
const prisma_1 = require("../lib/prisma");
const errors_1 = require("../lib/errors");
const crud_1 = require("../lib/crud");
const activity_1 = require("../lib/activity");
const query_1 = require("../lib/query");
const constants_1 = require("../../shared/constants");
const schemas_1 = require("../../shared/schemas");
exports.projectsRouter = (0, express_1.Router)();
const listInclude = {
    stages: { orderBy: { sortOrder: 'asc' } },
    _count: { select: { properties: true, dprs: true, milestones: true } },
};
/** Compact list for dropdowns — no relations, no pagination envelope. */
exports.projectsRouter.get('/options', (0, errors_1.asyncHandler)(async (_req, res) => {
    const rows = await prisma_1.prisma.project.findMany({
        select: { id: true, name: true, code: true, status: true },
        orderBy: { name: 'asc' },
    });
    res.json(rows);
}));
exports.projectsRouter.get('/:id/stages', (0, errors_1.asyncHandler)(async (req, res) => {
    const projectId = Number(req.params.id);
    const stages = await prisma_1.prisma.projectStage.findMany({
        where: { projectId },
        orderBy: { sortOrder: 'asc' },
        include: { progressLogs: { orderBy: { recordedOn: 'desc' }, take: 20 } },
    });
    res.json(stages);
}));
exports.projectsRouter.post('/:id/stages', (0, errors_1.asyncHandler)(async (req, res) => {
    const projectId = Number(req.params.id);
    const project = await prisma_1.prisma.project.findUnique({ where: { id: projectId } });
    if (!project)
        throw (0, errors_1.notFound)('Project');
    const input = schemas_1.stageSchema.parse(req.body);
    const stage = await prisma_1.prisma.projectStage.create({ data: { ...input, projectId } });
    res.status(201).json(stage);
}));
/**
 * Recording progress writes both the current value and a history row — the
 * history is what the forecasting engine measures the rate of work from.
 */
exports.projectsRouter.post('/stages/:stageId/progress', (0, errors_1.asyncHandler)(async (req, res) => {
    const stageId = Number(req.params.stageId);
    const stage = await prisma_1.prisma.projectStage.findUnique({ where: { id: stageId } });
    if (!stage)
        throw (0, errors_1.notFound)('Stage');
    const input = schemas_1.stageProgressSchema.parse(req.body);
    if (input.progress < stage.progress) {
        // Allowed (corrections happen) but worth recording explicitly.
        await (0, activity_1.logActivity)({
            actor: req.user?.username ?? 'system',
            action: 'PROGRESS_DOWN',
            entity: 'ProjectStage',
            entityId: stageId,
            detail: `${stage.progress}% → ${input.progress}%`,
        });
    }
    const [updated] = await prisma_1.prisma.$transaction([
        prisma_1.prisma.projectStage.update({ where: { id: stageId }, data: { progress: input.progress } }),
        prisma_1.prisma.stageProgressLog.create({
            data: {
                stageId,
                progress: input.progress,
                recordedOn: input.recordedOn,
                note: input.note ?? null,
            },
        }),
    ]);
    res.json(updated);
}));
exports.projectsRouter.put('/stages/:stageId', (0, errors_1.asyncHandler)(async (req, res) => {
    const stageId = Number(req.params.stageId);
    const input = schemas_1.stageSchema.parse(req.body);
    const stage = await prisma_1.prisma.projectStage.update({ where: { id: stageId }, data: input });
    res.json(stage);
}));
exports.projectsRouter.delete('/stages/:stageId', (0, errors_1.asyncHandler)(async (req, res) => {
    await prisma_1.prisma.projectStage.delete({ where: { id: Number(req.params.stageId) } });
    res.json({ ok: true });
}));
/** Progress, spend and open milestones for one project. */
exports.projectsRouter.get('/:id/overview', (0, errors_1.asyncHandler)(async (req, res) => {
    const projectId = Number(req.params.id);
    const project = await prisma_1.prisma.project.findUnique({
        where: { id: projectId },
        include: { stages: { orderBy: { sortOrder: 'asc' } }, milestones: { orderBy: { dueDate: 'asc' } } },
    });
    if (!project)
        throw (0, errors_1.notFound)('Project');
    const [properties, usage, attendance, dprCount] = await Promise.all([
        prisma_1.prisma.property.groupBy({ by: ['status'], where: { projectId }, _count: { _all: true } }),
        prisma_1.prisma.materialUsage.findMany({
            where: { projectId },
            include: { material: { select: { rate: true } } },
        }),
        prisma_1.prisma.attendance.count({ where: { projectId } }),
        prisma_1.prisma.dpr.count({ where: { projectId } }),
    ]);
    const totalWeight = project.stages.reduce((acc, stage) => acc + (stage.weight > 0 ? stage.weight : 1), 0) || 1;
    const progress = (0, query_1.round)(project.stages.reduce((acc, stage) => acc + stage.progress * (stage.weight > 0 ? stage.weight : 1), 0) / totalWeight, 1);
    res.json({
        project,
        progress,
        properties: Object.fromEntries(properties.map((row) => [row.status, row._count._all])),
        materialValue: (0, query_1.round)(usage.reduce((acc, row) => acc + row.quantity * (row.material?.rate ?? 0), 0), 2),
        attendanceEntries: attendance,
        dprCount,
    });
}));
exports.projectsRouter.use((0, crud_1.crudRouter)({
    delegate: prisma_1.prisma.project,
    entity: 'Project',
    schema: schemas_1.projectSchema,
    searchFields: ['name', 'code', 'location', 'contractor', 'engineer'],
    sortable: ['name', 'code', 'startDate', 'expectedEndDate', 'budget', 'createdAt'],
    defaultSort: 'startDate',
    dateField: 'startDate',
    listInclude,
    filters: (query) => (query.status ? { status: query.status } : null),
    /** A new project starts with the standard construction stages. */
    afterWrite: async (row, mode) => {
        if (mode !== 'create')
            return;
        await prisma_1.prisma.projectStage.createMany({
            data: constants_1.DEFAULT_STAGES.map((stage, index) => ({
                projectId: row.id,
                name: stage.name,
                weight: stage.weight,
                progress: 0,
                sortOrder: index,
            })),
        });
    },
}));
// ------------------------------------------------------------------ milestones
exports.milestonesRouter = (0, express_1.Router)();
exports.milestonesRouter.use((0, crud_1.crudRouter)({
    delegate: prisma_1.prisma.milestone,
    entity: 'Milestone',
    schema: schemas_1.milestoneSchema,
    searchFields: ['title', 'notes'],
    sortable: ['dueDate', 'status', 'createdAt'],
    defaultSort: 'dueDate',
    dateField: 'dueDate',
    listInclude: { project: { select: { id: true, name: true } } },
    filters: (query) => query.projectId ? { projectId: query.projectId } : query.status ? { status: query.status } : null,
}));
//# sourceMappingURL=projects.routes.js.map