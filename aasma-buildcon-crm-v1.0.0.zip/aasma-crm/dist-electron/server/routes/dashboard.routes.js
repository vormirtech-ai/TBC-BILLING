"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dashboardRouter = void 0;
const express_1 = require("express");
const errors_1 = require("../lib/errors");
const dashboard_service_1 = require("../services/dashboard.service");
const stock_service_1 = require("../services/stock.service");
const prisma_1 = require("../lib/prisma");
const query_1 = require("../lib/query");
exports.dashboardRouter = (0, express_1.Router)();
exports.dashboardRouter.get('/summary', (0, errors_1.asyncHandler)(async (_req, res) => {
    res.json(await (0, dashboard_service_1.getDashboardSummary)());
}));
exports.dashboardRouter.get('/charts', (0, errors_1.asyncHandler)(async (_req, res) => {
    res.json(await (0, dashboard_service_1.getDashboardCharts)());
}));
/** The alert rail: overdue follow-ups, low stock and slipping milestones. */
exports.dashboardRouter.get('/alerts', (0, errors_1.asyncHandler)(async (_req, res) => {
    const today = new Date();
    const [followUps, lowStock, milestones, missingDpr] = await Promise.all([
        prisma_1.prisma.lead.findMany({
            where: { status: { notIn: ['WON', 'LOST'] }, followUpDate: { lte: (0, query_1.endOfDay)(today) } },
            select: { id: true, name: true, phone: true, followUpDate: true, status: true },
            orderBy: { followUpDate: 'asc' },
            take: 20,
        }),
        (0, stock_service_1.getLowStockRows)(),
        prisma_1.prisma.milestone.findMany({
            where: { status: { not: 'DONE' }, dueDate: { lte: (0, query_1.endOfDay)(today) } },
            include: { project: { select: { name: true } } },
            orderBy: { dueDate: 'asc' },
            take: 20,
        }),
        prisma_1.prisma.project.findMany({
            where: {
                status: 'ACTIVE',
                dprs: { none: { reportDate: { gte: (0, query_1.startOfDay)(today), lte: (0, query_1.endOfDay)(today) } } },
            },
            select: { id: true, name: true },
            take: 20,
        }),
    ]);
    res.json({
        followUps,
        lowStock: lowStock.slice(0, 20),
        milestones,
        missingDpr,
    });
}));
/** Recent audit entries, shown on the dashboard's activity card. */
exports.dashboardRouter.get('/activity', (0, errors_1.asyncHandler)(async (_req, res) => {
    const rows = await prisma_1.prisma.activityLog.findMany({ orderBy: { createdAt: 'desc' }, take: 25 });
    res.json(rows);
}));
//# sourceMappingURL=dashboard.routes.js.map