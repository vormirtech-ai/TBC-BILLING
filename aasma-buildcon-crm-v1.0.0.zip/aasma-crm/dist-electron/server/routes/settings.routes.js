"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.usersRouter = exports.settingsRouter = void 0;
const express_1 = require("express");
const prisma_1 = require("../lib/prisma");
const errors_1 = require("../lib/errors");
const auth_1 = require("../lib/auth");
const activity_1 = require("../lib/activity");
const settings_1 = require("../lib/settings");
const schemas_1 = require("../../shared/schemas");
exports.settingsRouter = (0, express_1.Router)();
exports.settingsRouter.get('/', (0, errors_1.asyncHandler)(async (_req, res) => {
    res.json(await (0, settings_1.getSettings)());
}));
exports.settingsRouter.put('/', (0, errors_1.asyncHandler)(async (req, res) => {
    const saved = await (0, settings_1.saveSettings)(req.body);
    await (0, activity_1.logActivity)({ actor: req.user?.username ?? 'system', action: 'UPDATE', entity: 'Settings' });
    res.json(saved);
}));
// ------------------------------------------------------------------ users
exports.usersRouter = (0, express_1.Router)();
exports.usersRouter.get('/', (0, auth_1.requireRole)('ADMIN'), (0, errors_1.asyncHandler)(async (_req, res) => {
    const rows = await prisma_1.prisma.user.findMany({
        select: { id: true, username: true, fullName: true, role: true, active: true, lastLoginAt: true, createdAt: true },
        orderBy: { createdAt: 'asc' },
    });
    res.json(rows);
}));
exports.usersRouter.post('/', (0, auth_1.requireRole)('ADMIN'), (0, errors_1.asyncHandler)(async (req, res) => {
    const input = schemas_1.userSchema.parse(req.body);
    if (!input.password)
        throw (0, errors_1.badRequest)('Set a password for the new user.');
    const user = await prisma_1.prisma.user.create({
        data: {
            username: input.username.toLowerCase(),
            fullName: input.fullName,
            role: input.role,
            active: input.active,
            passwordHash: await (0, auth_1.hashPassword)(input.password),
        },
        select: { id: true, username: true, fullName: true, role: true, active: true },
    });
    await (0, activity_1.logActivity)({ actor: req.user?.username ?? 'system', action: 'CREATE', entity: 'User', entityId: user.id });
    res.status(201).json(user);
}));
exports.usersRouter.put('/:id', (0, auth_1.requireRole)('ADMIN'), (0, errors_1.asyncHandler)(async (req, res) => {
    const id = Number(req.params.id);
    const input = schemas_1.userSchema.parse(req.body);
    const user = await prisma_1.prisma.user.update({
        where: { id },
        data: {
            username: input.username.toLowerCase(),
            fullName: input.fullName,
            role: input.role,
            active: input.active,
            ...(input.password ? { passwordHash: await (0, auth_1.hashPassword)(input.password) } : {}),
        },
        select: { id: true, username: true, fullName: true, role: true, active: true },
    });
    await (0, activity_1.logActivity)({ actor: req.user?.username ?? 'system', action: 'UPDATE', entity: 'User', entityId: id });
    res.json(user);
}));
exports.usersRouter.delete('/:id', (0, auth_1.requireRole)('ADMIN'), (0, errors_1.asyncHandler)(async (req, res) => {
    const id = Number(req.params.id);
    if (req.user?.id === id)
        throw (0, errors_1.badRequest)('You cannot delete the account you are signed in with.');
    const admins = await prisma_1.prisma.user.count({ where: { role: 'ADMIN', active: true } });
    const target = await prisma_1.prisma.user.findUnique({ where: { id } });
    if (target?.role === 'ADMIN' && admins <= 1)
        throw (0, errors_1.badRequest)('At least one administrator must remain.');
    await prisma_1.prisma.user.delete({ where: { id } });
    await (0, activity_1.logActivity)({ actor: req.user?.username ?? 'system', action: 'DELETE', entity: 'User', entityId: id });
    res.json({ ok: true });
}));
//# sourceMappingURL=settings.routes.js.map