"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.leadsRouter = void 0;
const express_1 = require("express");
const prisma_1 = require("../lib/prisma");
const errors_1 = require("../lib/errors");
const crud_1 = require("../lib/crud");
const activity_1 = require("../lib/activity");
const query_1 = require("../lib/query");
const schemas_1 = require("../../shared/schemas");
exports.leadsRouter = (0, express_1.Router)();
const listInclude = {
    interestedProperty: { select: { id: true, tower: true, unit: true, status: true } },
    project: { select: { id: true, name: true } },
};
/** Follow-ups that are due today or already overdue. */
exports.leadsRouter.get('/follow-ups', (0, errors_1.asyncHandler)(async (req, res) => {
    const days = Number(req.query.days ?? 7);
    const today = new Date();
    const rows = await prisma_1.prisma.lead.findMany({
        where: {
            status: { notIn: ['WON', 'LOST'] },
            followUpDate: { not: null, lte: (0, query_1.endOfDay)(new Date(today.getTime() + days * 86_400_000)) },
        },
        include: listInclude,
        orderBy: { followUpDate: 'asc' },
        take: 200,
    });
    const start = (0, query_1.startOfDay)(today);
    res.json({
        overdue: rows.filter((lead) => lead.followUpDate < start),
        today: rows.filter((lead) => lead.followUpDate >= start && lead.followUpDate <= (0, query_1.endOfDay)(today)),
        upcoming: rows.filter((lead) => lead.followUpDate > (0, query_1.endOfDay)(today)),
    });
}));
exports.leadsRouter.get('/:id/activities', (0, errors_1.asyncHandler)(async (req, res) => {
    const leadId = Number(req.params.id);
    const rows = await prisma_1.prisma.leadActivity.findMany({
        where: { leadId },
        orderBy: { happenedOn: 'desc' },
    });
    res.json(rows);
}));
exports.leadsRouter.post('/:id/activities', (0, errors_1.asyncHandler)(async (req, res) => {
    const leadId = Number(req.params.id);
    const lead = await prisma_1.prisma.lead.findUnique({ where: { id: leadId } });
    if (!lead)
        throw (0, errors_1.notFound)('Lead');
    const input = schemas_1.leadActivitySchema.parse(req.body);
    const row = await prisma_1.prisma.leadActivity.create({ data: { ...input, leadId } });
    res.status(201).json(row);
}));
/**
 * Converts a won lead into a client, optionally booking the unit the lead was
 * interested in. Everything happens in one transaction so a half-converted lead
 * can never exist.
 */
exports.leadsRouter.post('/:id/convert', (0, errors_1.asyncHandler)(async (req, res) => {
    const leadId = Number(req.params.id);
    const input = schemas_1.convertLeadSchema.parse(req.body);
    const lead = await prisma_1.prisma.lead.findUnique({ where: { id: leadId } });
    if (!lead)
        throw (0, errors_1.notFound)('Lead');
    const actor = req.user?.username ?? 'system';
    const result = await prisma_1.prisma.$transaction(async (tx) => {
        const client = await tx.client.create({
            data: {
                name: lead.name,
                phone: lead.phone,
                email: lead.email,
                address: input.address ?? null,
                panNo: input.panNo ?? null,
                notes: lead.notes,
            },
        });
        await tx.interaction.create({
            data: {
                clientId: client.id,
                type: 'NOTE',
                detail: `Converted from lead #${lead.id} (${lead.source.toLowerCase()}).`,
            },
        });
        const propertyId = input.propertyId ?? lead.interestedPropertyId ?? null;
        if (input.createBooking && propertyId) {
            const property = await tx.property.findUnique({ where: { id: propertyId } });
            if (!property)
                throw (0, errors_1.notFound)('Property');
            await tx.booking.create({
                data: {
                    clientId: client.id,
                    propertyId,
                    projectId: property.projectId,
                    bookingDate: new Date(),
                    agreementValue: input.agreementValue || property.price,
                    bookingAmount: input.bookingAmount,
                },
            });
            await tx.property.update({ where: { id: propertyId }, data: { status: 'SOLD' } });
        }
        await tx.lead.update({
            where: { id: lead.id },
            data: { status: 'WON', convertedClientId: client.id },
        });
        await tx.leadActivity.create({
            data: { leadId: lead.id, type: 'STATUS_CHANGE', detail: `Converted to client #${client.id}.` },
        });
        return client;
    });
    await (0, activity_1.logActivity)({ actor, action: 'CONVERT', entity: 'Lead', entityId: leadId, detail: `Client #${result.id}` });
    res.status(201).json(result);
}));
exports.leadsRouter.use((0, crud_1.crudRouter)({
    delegate: prisma_1.prisma.lead,
    entity: 'Lead',
    schema: schemas_1.leadSchema,
    searchFields: ['name', 'phone', 'email', 'assignedTo', 'notes'],
    sortable: ['createdAt', 'name', 'budget', 'followUpDate', 'status'],
    defaultSort: 'createdAt',
    dateField: 'createdAt',
    listInclude,
    detailInclude: { ...listInclude, activities: { orderBy: { happenedOn: 'desc' } } },
    filters: (query) => (0, query_1.combine)(query.status ? { status: query.status } : null, query.source ? { source: query.source } : null, query.projectId ? { projectId: query.projectId } : null),
    afterWrite: async (row, mode, actor) => {
        if (mode === 'create') {
            await prisma_1.prisma.leadActivity.create({
                data: { leadId: row.id, type: 'NOTE', detail: `Lead created by ${actor}.` },
            });
        }
    },
}));
/** Used by the pipeline board to move a lead between columns. */
exports.leadsRouter.patch('/:id/status', (0, errors_1.asyncHandler)(async (req, res) => {
    const id = Number(req.params.id);
    const status = schemas_1.leadSchema.shape.status.parse(req.body.status);
    const lead = await prisma_1.prisma.lead.findUnique({ where: { id } });
    if (!lead)
        throw (0, errors_1.notFound)('Lead');
    const updated = await prisma_1.prisma.lead.update({ where: { id }, data: { status } });
    await prisma_1.prisma.leadActivity.create({
        data: { leadId: id, type: 'STATUS_CHANGE', detail: `Status changed from ${lead.status} to ${status}.` },
    });
    await (0, activity_1.logActivity)({
        actor: req.user?.username ?? 'system',
        action: 'STATUS',
        entity: 'Lead',
        entityId: id,
        detail: status,
    });
    res.json(updated);
}));
//# sourceMappingURL=leads.routes.js.map