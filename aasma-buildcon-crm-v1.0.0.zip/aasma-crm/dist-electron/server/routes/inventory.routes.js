"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.adjustmentsRouter = exports.usageRouter = exports.purchasesRouter = exports.materialsRouter = void 0;
const express_1 = require("express");
const prisma_1 = require("../lib/prisma");
const errors_1 = require("../lib/errors");
const crud_1 = require("../lib/crud");
const query_1 = require("../lib/query");
const schemas_1 = require("../../shared/schemas");
const stock_service_1 = require("../services/stock.service");
exports.materialsRouter = (0, express_1.Router)();
exports.materialsRouter.get('/options', (0, errors_1.asyncHandler)(async (_req, res) => {
    const rows = await prisma_1.prisma.material.findMany({
        where: { active: true },
        select: { id: true, name: true, unit: true, rate: true, category: true },
        orderBy: { name: 'asc' },
    });
    res.json(rows);
}));
/** Live stock for every material, with a low-stock flag. */
exports.materialsRouter.get('/stock', (0, errors_1.asyncHandler)(async (req, res) => {
    const rows = await (0, stock_service_1.getStockRows)({
        q: typeof req.query.q === 'string' ? req.query.q : undefined,
        category: typeof req.query.category === 'string' ? req.query.category : undefined,
    });
    res.json({
        rows,
        totals: {
            materials: rows.length,
            stockValue: (0, query_1.round)(rows.reduce((acc, row) => acc + row.stockValue, 0), 2),
            lowStock: rows.filter((row) => row.low).length,
        },
    });
}));
/** Every movement for one material, newest first. */
exports.materialsRouter.get('/:id/ledger', (0, errors_1.asyncHandler)(async (req, res) => {
    const materialId = Number(req.params.id);
    const [purchases, usages, adjustments, stock] = await Promise.all([
        prisma_1.prisma.purchase.findMany({ where: { materialId }, include: { project: { select: { name: true } } } }),
        prisma_1.prisma.materialUsage.findMany({ where: { materialId }, include: { project: { select: { name: true } } } }),
        prisma_1.prisma.stockAdjustment.findMany({ where: { materialId } }),
        (0, stock_service_1.getStockForMaterial)(materialId),
    ]);
    const entries = [
        ...purchases.map((row) => ({
            id: `P${row.id}`,
            at: row.purchasedOn.toISOString(),
            type: 'PURCHASE',
            quantity: row.quantity,
            detail: `${row.supplier ?? 'Purchase'}${row.invoiceNo ? ` • ${row.invoiceNo}` : ''}`,
            project: row.project?.name ?? '',
        })),
        ...usages.map((row) => ({
            id: `U${row.id}`,
            at: row.usedOn.toISOString(),
            type: 'ISSUE',
            quantity: -row.quantity,
            detail: row.issuedTo ? `Issued to ${row.issuedTo}` : 'Issued to site',
            project: row.project?.name ?? '',
        })),
        ...adjustments.map((row) => ({
            id: `A${row.id}`,
            at: row.adjustedOn.toISOString(),
            type: 'ADJUSTMENT',
            quantity: row.quantity,
            detail: row.reason,
            project: '',
        })),
    ].sort((a, b) => b.at.localeCompare(a.at));
    res.json({ stock, entries });
}));
exports.materialsRouter.use((0, crud_1.crudRouter)({
    delegate: prisma_1.prisma.material,
    entity: 'Material',
    schema: schemas_1.materialSchema,
    searchFields: ['name', 'category', 'unit'],
    sortable: ['name', 'category', 'rate', 'createdAt'],
    defaultSort: 'name',
    filters: (query) => (query.category ? { category: query.category } : null),
}));
// ------------------------------------------------------------------ purchases
exports.purchasesRouter = (0, express_1.Router)();
exports.purchasesRouter.use((0, crud_1.crudRouter)({
    delegate: prisma_1.prisma.purchase,
    entity: 'Purchase',
    schema: schemas_1.purchaseSchema,
    searchFields: ['supplier', 'invoiceNo', 'notes'],
    sortable: ['purchasedOn', 'amount', 'quantity', 'createdAt'],
    defaultSort: 'purchasedOn',
    dateField: 'purchasedOn',
    listInclude: {
        material: { select: { id: true, name: true, unit: true } },
        project: { select: { id: true, name: true } },
    },
    filters: (query) => (0, query_1.combine)(query.materialId ? { materialId: query.materialId } : null, query.projectId ? { projectId: query.projectId } : null),
    // Amount is always quantity × rate, never whatever the client sent.
    toData: (input) => ({ ...input, amount: (0, query_1.round)(input.quantity * input.rate, 2) }),
}));
// ------------------------------------------------------------------ issues
exports.usageRouter = (0, express_1.Router)();
exports.usageRouter.use((0, crud_1.crudRouter)({
    delegate: prisma_1.prisma.materialUsage,
    entity: 'Material issue',
    schema: schemas_1.materialUsageSchema,
    searchFields: ['issuedTo', 'notes'],
    sortable: ['usedOn', 'quantity', 'createdAt'],
    defaultSort: 'usedOn',
    dateField: 'usedOn',
    listInclude: {
        material: { select: { id: true, name: true, unit: true, rate: true } },
        project: { select: { id: true, name: true } },
    },
    filters: (query) => (0, query_1.combine)(query.materialId ? { materialId: query.materialId } : null, query.projectId ? { projectId: query.projectId } : null),
}));
/** Consumption summary used by the Material Consumption report card. */
exports.usageRouter.get('/summary/consumption', (0, errors_1.asyncHandler)(async (req, res) => {
    const to = req.query.to ? new Date(String(req.query.to)) : new Date();
    const from = req.query.from ? new Date(String(req.query.from)) : (0, query_1.addDays)(to, -29);
    const projectId = req.query.projectId ? Number(req.query.projectId) : undefined;
    const usages = await prisma_1.prisma.materialUsage.findMany({
        where: {
            usedOn: { gte: (0, query_1.startOfDay)(from), lte: (0, query_1.endOfDay)(to) },
            ...(projectId ? { projectId } : {}),
        },
        include: { material: { select: { name: true, unit: true, rate: true } } },
    });
    const byMaterial = new Map();
    const byDay = new Map();
    for (const usage of usages) {
        const name = usage.material?.name ?? `Material ${usage.materialId}`;
        const entry = byMaterial.get(name) ?? { name, unit: usage.material?.unit ?? '', quantity: 0, value: 0 };
        entry.quantity += usage.quantity;
        entry.value += usage.quantity * (usage.material?.rate ?? 0);
        byMaterial.set(name, entry);
        const day = usage.usedOn.toISOString().slice(0, 10);
        byDay.set(day, (byDay.get(day) ?? 0) + usage.quantity * (usage.material?.rate ?? 0));
    }
    const stock = await (0, stock_service_1.getStockRows)();
    const stockByName = new Map(stock.map((row) => [row.name, row.inStock]));
    res.json({
        from: (0, query_1.startOfDay)(from).toISOString(),
        to: (0, query_1.endOfDay)(to).toISOString(),
        byMaterial: Array.from(byMaterial.values())
            .map((entry) => ({
            ...entry,
            quantity: (0, query_1.round)(entry.quantity, 2),
            value: (0, query_1.round)(entry.value, 2),
            remaining: stockByName.get(entry.name) ?? 0,
        }))
            .sort((a, b) => b.value - a.value),
        byDay: Array.from(byDay.entries())
            .sort((a, b) => a[0].localeCompare(b[0]))
            .map(([date, value]) => ({ date, value: (0, query_1.round)(value, 2) })),
        totalValue: (0, query_1.round)(usages.reduce((acc, row) => acc + row.quantity * (row.material?.rate ?? 0), 0), 2),
    });
}));
// ------------------------------------------------------------------ adjustments
exports.adjustmentsRouter = (0, express_1.Router)();
exports.adjustmentsRouter.use((0, crud_1.crudRouter)({
    delegate: prisma_1.prisma.stockAdjustment,
    entity: 'Stock adjustment',
    schema: schemas_1.stockAdjustmentSchema,
    searchFields: ['reason', 'notes'],
    sortable: ['adjustedOn', 'quantity', 'createdAt'],
    defaultSort: 'adjustedOn',
    dateField: 'adjustedOn',
    listInclude: { material: { select: { id: true, name: true, unit: true } } },
    filters: (query) => (query.materialId ? { materialId: query.materialId } : null),
}));
/** Guard: never let an adjustment push recorded stock below zero. */
exports.adjustmentsRouter.post('/validate', (0, errors_1.asyncHandler)(async (req, res) => {
    const input = schemas_1.stockAdjustmentSchema.parse(req.body);
    const stock = await (0, stock_service_1.getStockForMaterial)(input.materialId);
    if (!stock)
        throw (0, errors_1.badRequest)('Unknown material.');
    const resulting = (0, query_1.round)(stock.inStock + input.quantity, 3);
    res.json({ current: stock.inStock, resulting, allowed: resulting >= 0 });
}));
//# sourceMappingURL=inventory.routes.js.map