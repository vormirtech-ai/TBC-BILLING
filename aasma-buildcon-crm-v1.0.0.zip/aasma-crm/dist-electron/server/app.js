"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createApp = createApp;
const node_path_1 = __importDefault(require("node:path"));
const compression_1 = __importDefault(require("compression"));
const cors_1 = __importDefault(require("cors"));
const express_1 = __importDefault(require("express"));
const paths_1 = require("./lib/paths");
const errors_1 = require("./lib/errors");
const auth_1 = require("./lib/auth");
const auth_routes_1 = require("./routes/auth.routes");
const leads_routes_1 = require("./routes/leads.routes");
const clients_routes_1 = require("./routes/clients.routes");
const projects_routes_1 = require("./routes/projects.routes");
const properties_routes_1 = require("./routes/properties.routes");
const inventory_routes_1 = require("./routes/inventory.routes");
const labour_routes_1 = require("./routes/labour.routes");
const dpr_routes_1 = require("./routes/dpr.routes");
const dashboard_routes_1 = require("./routes/dashboard.routes");
const forecast_routes_1 = require("./routes/forecast.routes");
const reports_routes_1 = require("./routes/reports.routes");
const settings_routes_1 = require("./routes/settings.routes");
const backup_routes_1 = require("./routes/backup.routes");
const search_routes_1 = require("./routes/search.routes");
/**
 * The whole API. It only ever listens on the loopback interface, so nothing on
 * the network can reach it — this is a single-machine application.
 */
function createApp() {
    const app = (0, express_1.default)();
    app.disable('x-powered-by');
    app.use((0, compression_1.default)());
    app.use((0, cors_1.default)({ origin: [/^http:\/\/localhost:\d+$/, /^http:\/\/127\.0\.0\.1:\d+$/], credentials: false }));
    app.use(express_1.default.json({ limit: '8mb' }));
    app.use(express_1.default.urlencoded({ extended: true, limit: '8mb' }));
    app.get('/api/health', (_req, res) => {
        res.json({ ok: true, version: '1.0.0', database: paths_1.PATHS.databaseFile });
    });
    app.use('/api/auth', auth_routes_1.authRouter);
    // Everything below this line needs a valid token.
    const api = express_1.default.Router();
    api.use(auth_1.requireAuth);
    api.use('/dashboard', dashboard_routes_1.dashboardRouter);
    api.use('/leads', leads_routes_1.leadsRouter);
    api.use('/clients', clients_routes_1.clientsRouter);
    api.use('/bookings', clients_routes_1.bookingsRouter);
    api.use('/payments', clients_routes_1.paymentsRouter);
    api.use('/projects', projects_routes_1.projectsRouter);
    api.use('/milestones', projects_routes_1.milestonesRouter);
    api.use('/properties', properties_routes_1.propertiesRouter);
    api.use('/materials', inventory_routes_1.materialsRouter);
    api.use('/purchases', inventory_routes_1.purchasesRouter);
    api.use('/usage', inventory_routes_1.usageRouter);
    api.use('/adjustments', inventory_routes_1.adjustmentsRouter);
    api.use('/workers', labour_routes_1.workersRouter);
    api.use('/attendance', labour_routes_1.attendanceRouter);
    api.use('/dpr', dpr_routes_1.dprRouter);
    api.use('/forecast', forecast_routes_1.forecastRouter);
    api.use('/reports', reports_routes_1.reportsRouter);
    api.use('/settings', settings_routes_1.settingsRouter);
    api.use('/users', settings_routes_1.usersRouter);
    api.use('/backups', backup_routes_1.backupRouter);
    api.use('/search', search_routes_1.searchRouter);
    app.use('/api', api);
    // Locally stored DPR photos and client documents.
    app.use('/files', express_1.default.static(paths_1.PATHS.uploadsDir, { maxAge: '1h', index: false, dotfiles: 'deny' }));
    // In production the built renderer is served from the same origin, which keeps
    // the packaged app working without any dev server.
    if (process.env.NODE_ENV !== 'development') {
        app.use(express_1.default.static(paths_1.PATHS.rendererDir, { index: 'index.html' }));
        app.get(/^(?!\/api|\/files).*/, (_req, res) => {
            res.sendFile(node_path_1.default.join(paths_1.PATHS.rendererDir, 'index.html'));
        });
    }
    app.use((_req, res) => {
        res.status(404).json({ error: 'That endpoint does not exist.' });
    });
    app.use(errors_1.errorMiddleware);
    return app;
}
//# sourceMappingURL=app.js.map