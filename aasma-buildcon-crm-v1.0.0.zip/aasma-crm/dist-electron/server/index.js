"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.startServer = startServer;
const app_1 = require("./app");
const bootstrap_1 = require("./bootstrap");
const prisma_1 = require("./lib/prisma");
const DEFAULT_PORT = Number(process.env.API_PORT ?? 4317);
/**
 * Starts the API on the first free port from the preferred one upwards, so a
 * second copy of the app (or an unrelated service) cannot stop it from opening.
 */
async function startServer(preferredPort = DEFAULT_PORT) {
    await (0, bootstrap_1.prepareDatabase)();
    const app = (0, app_1.createApp)();
    const listen = (port) => new Promise((resolve, reject) => {
        const server = app.listen(port, '127.0.0.1');
        server.once('listening', () => resolve(server));
        server.once('error', reject);
    });
    let server = null;
    let port = preferredPort;
    for (let attempt = 0; attempt < 12; attempt += 1) {
        try {
            server = await listen(port);
            break;
        }
        catch (error) {
            const code = error.code;
            if (code !== 'EADDRINUSE')
                throw error;
            port += 1;
        }
    }
    if (!server)
        throw new Error('Could not find a free port for the local API.');
    const running = server;
    console.log(`[api] Aasma Buildcon CRM API listening on http://127.0.0.1:${port}`);
    return {
        port,
        url: `http://127.0.0.1:${port}`,
        stop: async () => {
            await new Promise((resolve) => running.close(() => resolve()));
            await (0, prisma_1.disconnectPrisma)();
        },
    };
}
//# sourceMappingURL=index.js.map