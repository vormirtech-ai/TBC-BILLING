"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_ADMIN = void 0;
exports.ensureDatabase = ensureDatabase;
exports.ensureAdminUser = ensureAdminUser;
exports.prepareDatabase = prepareDatabase;
const node_child_process_1 = require("node:child_process");
const node_fs_1 = __importDefault(require("node:fs"));
const node_path_1 = __importDefault(require("node:path"));
const paths_1 = require("./lib/paths");
const prisma_1 = require("./lib/prisma");
const auth_1 = require("./lib/auth");
/**
 * Makes sure there is a usable database before the API accepts a request.
 *
 * Three situations, in order of preference:
 *   1. The database already exists — nothing to do.
 *   2. A template database was shipped with the build — copy it. This is how a
 *      packaged install starts up on a machine with no toolchain and no network.
 *   3. Neither — run `prisma db push` from the local node_modules (development
 *      and "run from source" installs).
 */
function ensureDatabase() {
    (0, paths_1.ensureDirectories)();
    if (node_fs_1.default.existsSync(paths_1.PATHS.databaseFile) && node_fs_1.default.statSync(paths_1.PATHS.databaseFile).size > 0)
        return;
    if (node_fs_1.default.existsSync(paths_1.PATHS.templateDatabase)) {
        node_fs_1.default.copyFileSync(paths_1.PATHS.templateDatabase, paths_1.PATHS.databaseFile);
        console.log('[db] created a new database from the shipped template.');
        return;
    }
    const cli = node_path_1.default.join(paths_1.PATHS.appRoot, 'node_modules', 'prisma', 'build', 'index.js');
    if (!node_fs_1.default.existsSync(cli)) {
        throw new Error(`No database found at ${paths_1.PATHS.databaseFile} and no way to create one. ` +
            'Run "npm run db:setup" in the application folder.');
    }
    console.log('[db] no database found — creating one from the Prisma schema…');
    (0, node_child_process_1.execFileSync)(process.execPath, [cli, 'db', 'push', '--skip-generate'], {
        cwd: paths_1.PATHS.appRoot,
        stdio: 'inherit',
        env: {
            ...process.env,
            // Lets this work when the host process is Electron rather than plain Node.
            ELECTRON_RUN_AS_NODE: '1',
            DATABASE_URL: (0, paths_1.databaseUrl)(),
        },
    });
}
exports.DEFAULT_ADMIN = { username: 'admin', password: 'admin@123' };
/** Creates the first administrator so a fresh install can be signed into. */
async function ensureAdminUser() {
    const count = await prisma_1.prisma.user.count();
    if (count > 0)
        return;
    await prisma_1.prisma.user.create({
        data: {
            username: exports.DEFAULT_ADMIN.username,
            fullName: 'Administrator',
            role: 'ADMIN',
            passwordHash: await (0, auth_1.hashPassword)(exports.DEFAULT_ADMIN.password),
        },
    });
    console.log(`[auth] created the default administrator — username "${exports.DEFAULT_ADMIN.username}", password "${exports.DEFAULT_ADMIN.password}". Change it from Settings after signing in.`);
}
async function prepareDatabase() {
    ensureDatabase();
    await (0, prisma_1.tuneSqlite)();
    await ensureAdminUser();
}
//# sourceMappingURL=bootstrap.js.map