"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getStockRows = getStockRows;
exports.getStockForMaterial = getStockForMaterial;
exports.getLowStockRows = getLowStockRows;
const prisma_1 = require("../lib/prisma");
const query_1 = require("../lib/query");
/**
 * Live stock is never stored as a column — it is derived from opening stock plus
 * purchases, minus issues, plus adjustments. Deriving it keeps the ledger and
 * the balance from ever drifting apart.
 */
async function getStockRows(filter) {
    const materials = await prisma_1.prisma.material.findMany({
        where: {
            ...(filter?.category ? { category: filter.category } : {}),
            ...(filter?.q ? { name: { contains: filter.q } } : {}),
        },
        orderBy: { name: 'asc' },
    });
    const [purchases, usages, adjustments] = await Promise.all([
        prisma_1.prisma.purchase.groupBy({ by: ['materialId'], _sum: { quantity: true } }),
        prisma_1.prisma.materialUsage.groupBy({ by: ['materialId'], _sum: { quantity: true } }),
        prisma_1.prisma.stockAdjustment.groupBy({ by: ['materialId'], _sum: { quantity: true } }),
    ]);
    const sumBy = (rows) => new Map(rows.map((row) => [row.materialId, row._sum.quantity ?? 0]));
    const purchasedMap = sumBy(purchases);
    const usedMap = sumBy(usages);
    const adjustedMap = sumBy(adjustments);
    return materials.map((material) => {
        const purchased = purchasedMap.get(material.id) ?? 0;
        const used = usedMap.get(material.id) ?? 0;
        const adjusted = adjustedMap.get(material.id) ?? 0;
        const inStock = (0, query_1.round)(material.openingStock + purchased - used + adjusted, 3);
        return {
            id: material.id,
            name: material.name,
            category: material.category,
            unit: material.unit,
            rate: material.rate,
            openingStock: material.openingStock,
            purchased: (0, query_1.round)(purchased, 3),
            used: (0, query_1.round)(used, 3),
            adjusted: (0, query_1.round)(adjusted, 3),
            inStock,
            reorderLevel: material.reorderLevel,
            stockValue: (0, query_1.round)(inStock * material.rate, 2),
            low: inStock <= material.reorderLevel,
        };
    });
}
async function getStockForMaterial(materialId) {
    const rows = await getStockRows();
    return rows.find((row) => row.id === materialId) ?? null;
}
async function getLowStockRows() {
    const rows = await getStockRows();
    return rows.filter((row) => row.low);
}
//# sourceMappingURL=stock.service.js.map