"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createBackup = createBackup;
exports.listBackups = listBackups;
exports.backupPath = backupPath;
exports.restoreBackup = restoreBackup;
exports.deleteBackup = deleteBackup;
exports.importBackupFile = importBackupFile;
const node_fs_1 = __importDefault(require("node:fs"));
const node_path_1 = __importDefault(require("node:path"));
const paths_1 = require("../lib/paths");
const prisma_1 = require("../lib/prisma");
const errors_1 = require("../lib/errors");
const PREFIX = 'CRM_Backup_';
/**
 * Backups are a straight file copy of the SQLite database. `VACUUM INTO` is used
 * so the copy is a consistent, compacted snapshot even while the app is running
 * and the write-ahead log has uncommitted pages.
 */
async function createBackup() {
    (0, paths_1.ensureDirectories)();
    const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const fileName = `${PREFIX}${stamp}.db`;
    const target = node_path_1.default.join(paths_1.PATHS.backupsDir, fileName);
    // VACUUM INTO refuses to overwrite, which is exactly the behaviour we want.
    await prisma_1.prisma.$executeRawUnsafe(`VACUUM INTO '${target.split(node_path_1.default.sep).join('/').replace(/'/g, "''")}'`);
    const stats = node_fs_1.default.statSync(target);
    return { name: fileName, size: stats.size, createdAt: stats.birthtime.toISOString() };
}
function listBackups() {
    (0, paths_1.ensureDirectories)();
    return node_fs_1.default
        .readdirSync(paths_1.PATHS.backupsDir)
        .filter((name) => name.endsWith('.db'))
        .map((name) => {
        const stats = node_fs_1.default.statSync(node_path_1.default.join(paths_1.PATHS.backupsDir, name));
        return { name, size: stats.size, createdAt: stats.birthtime.toISOString() };
    })
        .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}
function resolveBackup(name) {
    // Never let a caller escape the backups folder.
    const safe = node_path_1.default.basename(name);
    if (!safe.endsWith('.db'))
        throw (0, errors_1.badRequest)('That is not a backup file.');
    const target = node_path_1.default.join(paths_1.PATHS.backupsDir, safe);
    if (!node_fs_1.default.existsSync(target))
        throw (0, errors_1.notFound)('Backup');
    return target;
}
function backupPath(name) {
    return resolveBackup(name);
}
/**
 * Restores a backup over the live database. The current database is copied to a
 * "pre-restore" backup first, so a mistaken restore is itself recoverable. The
 * caller is expected to restart the app afterwards.
 */
async function restoreBackup(name) {
    const source = resolveBackup(name);
    const stats = node_fs_1.default.statSync(source);
    if (stats.size < 1024)
        throw new errors_1.HttpError(422, 'That backup file looks empty or corrupted.');
    const safetyName = `${PREFIX}pre-restore-${new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)}.db`;
    const safetyTarget = node_path_1.default.join(paths_1.PATHS.backupsDir, safetyName);
    await prisma_1.prisma.$executeRawUnsafe(`VACUUM INTO '${safetyTarget.split(node_path_1.default.sep).join('/').replace(/'/g, "''")}'`);
    await prisma_1.prisma.$disconnect();
    // Remove the WAL/shm side files, otherwise SQLite would replay them on top of
    // the freshly restored database.
    for (const suffix of ['-wal', '-shm']) {
        const sideFile = `${paths_1.PATHS.databaseFile}${suffix}`;
        if (node_fs_1.default.existsSync(sideFile))
            node_fs_1.default.rmSync(sideFile);
    }
    node_fs_1.default.copyFileSync(source, paths_1.PATHS.databaseFile);
    return { restoredFrom: node_path_1.default.basename(source), safetyCopy: safetyName };
}
function deleteBackup(name) {
    node_fs_1.default.rmSync(resolveBackup(name));
}
function importBackupFile(tempPath, originalName) {
    (0, paths_1.ensureDirectories)();
    const safe = `${PREFIX}imported-${Date.now()}-${node_path_1.default.basename(originalName).replace(/[^A-Za-z0-9._-]/g, '_')}`;
    const target = node_path_1.default.join(paths_1.PATHS.backupsDir, safe.endsWith('.db') ? safe : `${safe}.db`);
    node_fs_1.default.copyFileSync(tempPath, target);
    node_fs_1.default.rmSync(tempPath, { force: true });
    const stats = node_fs_1.default.statSync(target);
    return { name: node_path_1.default.basename(target), size: stats.size, createdAt: stats.birthtime.toISOString() };
}
//# sourceMappingURL=backup.service.js.map