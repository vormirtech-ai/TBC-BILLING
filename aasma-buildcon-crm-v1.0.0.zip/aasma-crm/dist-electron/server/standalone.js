"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Runs the CRM without Electron — useful for a shared office machine where the
 * app is opened in a browser at http://localhost:4317 instead.
 *
 *   npm run build && npm run serve
 */
const index_1 = require("./index");
async function main() {
    const server = await (0, index_1.startServer)();
    console.log(`Open ${server.url} in your browser.`);
    const shutdown = async () => {
        await server.stop();
        process.exit(0);
    };
    process.on('SIGINT', shutdown);
    process.on('SIGTERM', shutdown);
}
main().catch((error) => {
    console.error('Could not start the CRM:', error);
    process.exit(1);
});
//# sourceMappingURL=standalone.js.map