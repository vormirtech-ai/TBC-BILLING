"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_path_1 = __importDefault(require("node:path"));
const electron_1 = require("electron");
/**
 * Electron entry point.
 *
 * The Express API runs inside this process, listening on loopback only, and the
 * window simply loads it. That keeps a single process to start and stop, and
 * means the same code serves the browser-only mode (`npm run serve`).
 */
const isDev = process.env.NODE_ENV === 'development';
const DEV_URL = 'http://localhost:5273';
// A packaged app cannot write next to its own executable, so data goes to the
// per-user application-data folder. This must be set before the server module is
// loaded, because the database path is resolved on import.
if (electron_1.app.isPackaged) {
    process.env.AASMA_DATA_DIR = electron_1.app.getPath('userData');
}
let mainWindow = null;
let server = null;
function buildMenu() {
    const template = [
        {
            label: 'File',
            submenu: [
                {
                    label: 'Open data folder',
                    click: () => {
                        void electron_1.shell.openPath(electron_1.app.isPackaged ? electron_1.app.getPath('userData') : process.cwd());
                    },
                },
                { type: 'separator' },
                { role: 'quit' },
            ],
        },
        {
            label: 'View',
            submenu: [
                { role: 'reload' },
                { role: 'forceReload' },
                { type: 'separator' },
                { role: 'resetZoom' },
                { role: 'zoomIn' },
                { role: 'zoomOut' },
                { type: 'separator' },
                { role: 'togglefullscreen' },
                ...(isDev ? [{ role: 'toggleDevTools' }] : []),
            ],
        },
        {
            label: 'Help',
            submenu: [
                {
                    label: 'About Aasma Buildcon CRM',
                    click: () => {
                        void electron_1.dialog.showMessageBox({
                            type: 'info',
                            title: 'Aasma Buildcon CRM',
                            message: 'Aasma Buildcon CRM',
                            detail: `Version ${electron_1.app.getVersion()}\n` +
                                'Offline CRM and construction ERP for Aasma Construction.\n\n' +
                                `Data folder: ${electron_1.app.isPackaged ? electron_1.app.getPath('userData') : process.cwd()}`,
                            buttons: ['Close'],
                        });
                    },
                },
            ],
        },
    ];
    electron_1.Menu.setApplicationMenu(electron_1.Menu.buildFromTemplate(template));
}
async function createWindow() {
    mainWindow = new electron_1.BrowserWindow({
        width: 1440,
        height: 900,
        minWidth: 1100,
        minHeight: 700,
        show: false,
        backgroundColor: '#F7F7F8',
        title: 'Aasma Buildcon CRM',
        icon: node_path_1.default.join(__dirname, '../../build/icon.png'),
        webPreferences: {
            preload: node_path_1.default.join(__dirname, 'preload.js'),
            contextIsolation: true,
            nodeIntegration: false,
            sandbox: false,
            spellcheck: false,
        },
    });
    mainWindow.once('ready-to-show', () => mainWindow?.show());
    mainWindow.on('closed', () => {
        mainWindow = null;
    });
    // Links to anything outside the app open in the user's browser, never inside
    // the application window.
    mainWindow.webContents.setWindowOpenHandler(({ url }) => {
        void electron_1.shell.openExternal(url);
        return { action: 'deny' };
    });
    const target = isDev ? DEV_URL : server.url;
    await mainWindow.loadURL(target);
    if (isDev)
        mainWindow.webContents.openDevTools({ mode: 'detach' });
}
function registerIpc() {
    electron_1.ipcMain.handle('app:info', () => ({
        version: electron_1.app.getVersion(),
        platform: process.platform,
        dataFolder: electron_1.app.isPackaged ? electron_1.app.getPath('userData') : process.cwd(),
        apiUrl: server?.url ?? '',
    }));
    electron_1.ipcMain.handle('app:open-folder', async (_event, kind) => {
        const root = electron_1.app.isPackaged ? electron_1.app.getPath('userData') : process.cwd();
        const folder = kind === 'data' ? node_path_1.default.join(root, 'data') : node_path_1.default.join(root, kind);
        const error = await electron_1.shell.openPath(folder);
        return { ok: error === '', error };
    });
    // Used after restoring a backup: the database file underneath us has changed.
    electron_1.ipcMain.handle('app:restart', () => {
        electron_1.app.relaunch();
        electron_1.app.exit(0);
    });
}
async function bootstrap() {
    try {
        // Required late so AASMA_DATA_DIR above is already in place.
        const { startServer } = require('../server/index');
        server = await startServer();
    }
    catch (error) {
        electron_1.dialog.showErrorBox('Aasma Buildcon CRM could not start', `The local database could not be opened.\n\n${error.message}`);
        electron_1.app.exit(1);
        return;
    }
    registerIpc();
    buildMenu();
    await createWindow();
}
const gotTheLock = electron_1.app.requestSingleInstanceLock();
if (!gotTheLock) {
    electron_1.app.quit();
}
else {
    electron_1.app.on('second-instance', () => {
        if (!mainWindow)
            return;
        if (mainWindow.isMinimized())
            mainWindow.restore();
        mainWindow.focus();
    });
    electron_1.app.whenReady().then(bootstrap).catch((error) => {
        electron_1.dialog.showErrorBox('Aasma Buildcon CRM', String(error));
        electron_1.app.exit(1);
    });
    electron_1.app.on('activate', () => {
        if (electron_1.BrowserWindow.getAllWindows().length === 0)
            void createWindow();
    });
    electron_1.app.on('window-all-closed', () => {
        if (process.platform !== 'darwin')
            electron_1.app.quit();
    });
    electron_1.app.on('before-quit', () => {
        void server?.stop();
    });
}
//# sourceMappingURL=main.js.map