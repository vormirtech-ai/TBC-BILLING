"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
/**
 * The only bridge between the page and the desktop shell. Nothing from Node is
 * exposed directly — just three named actions the Settings screen uses.
 */
const api = {
    isDesktop: true,
    info: () => electron_1.ipcRenderer.invoke('app:info'),
    openFolder: (kind) => electron_1.ipcRenderer.invoke('app:open-folder', kind),
    restart: () => electron_1.ipcRenderer.invoke('app:restart'),
};
electron_1.contextBridge.exposeInMainWorld('aasma', api);
//# sourceMappingURL=preload.js.map