"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.listQuerySchema = exports.settingsSchema = exports.dprSchema = exports.dprMaterialSchema = exports.attendanceDaySchema = exports.attendanceEntrySchema = exports.workerSchema = exports.stockAdjustmentSchema = exports.materialUsageSchema = exports.purchaseSchema = exports.materialSchema = exports.propertyImportSchema = exports.propertySchema = exports.milestoneSchema = exports.stageProgressSchema = exports.stageSchema = exports.projectSchema = exports.documentSchema = exports.interactionSchema = exports.paymentSchema = exports.bookingSchema = exports.clientSchema = exports.convertLeadSchema = exports.leadActivitySchema = exports.leadSchema = exports.userSchema = exports.changePasswordSchema = exports.loginSchema = void 0;
/**
 * Zod schemas shared by the Express API and the React forms.
 *
 * The server treats these as the trust boundary: nothing reaches Prisma without
 * passing through one of them. The client reuses the same schema in React Hook
 * Form, so a field can never be valid in the browser and rejected on the server.
 */
const zod_1 = require("zod");
const constants_1 = require("./constants");
const optionalText = zod_1.z
    .string()
    .trim()
    .max(4000)
    .optional()
    .nullable()
    .transform((value) => (value === '' ? null : (value ?? null)));
const requiredText = (label, max = 200) => zod_1.z.string({ required_error: `${label} is required` }).trim().min(1, `${label} is required`).max(max);
const money = zod_1.z.coerce.number().min(0, 'Cannot be negative').max(1_000_000_000_000);
const quantity = zod_1.z.coerce.number().min(0, 'Cannot be negative').max(100_000_000);
/**
 * Dates arrive either as an ISO string (an <input type="date"> value, or JSON on
 * the wire) or as a real Date. A union rather than z.coerce.date() keeps the
 * *input* type honest, so React Hook Form can hold the string the input element
 * actually gives it while the parsed value is always a Date.
 */
const toDate = (value) => (value instanceof Date ? value : new Date(value));
const dateValue = zod_1.z
    .union([zod_1.z.string().min(1, 'Enter a valid date'), zod_1.z.date()])
    .transform(toDate)
    .refine((value) => !Number.isNaN(value.getTime()), 'Enter a valid date');
const optionalDate = zod_1.z
    .union([zod_1.z.string(), zod_1.z.date()])
    .nullish()
    .transform((value) => (value === '' || value == null ? null : toDate(value)))
    .refine((value) => value === null || !Number.isNaN(value.getTime()), 'Enter a valid date');
const optionalId = zod_1.z.coerce.number().int().positive().optional().nullable();
const phone = zod_1.z
    .string()
    .trim()
    .min(6, 'Enter a valid phone number')
    .max(20, 'Enter a valid phone number')
    .regex(/^[0-9+\-\s()]+$/, 'Phone can only contain digits and + - ( )');
const optionalEmail = zod_1.z
    .string()
    .trim()
    .email('Enter a valid email')
    .max(200)
    .optional()
    .nullable()
    .or(zod_1.z.literal(''))
    .transform((value) => (value ? value : null));
// ------------------------------------------------------------------ auth
exports.loginSchema = zod_1.z.object({
    username: requiredText('Username', 60),
    password: zod_1.z.string().min(4, 'Password must be at least 4 characters').max(200),
});
exports.changePasswordSchema = zod_1.z
    .object({
    currentPassword: zod_1.z.string().min(1, 'Current password is required'),
    newPassword: zod_1.z
        .string()
        .min(8, 'Use at least 8 characters')
        .max(200)
        .regex(/[A-Za-z]/, 'Include at least one letter')
        .regex(/[0-9]/, 'Include at least one number'),
    confirmPassword: zod_1.z.string(),
})
    .refine((data) => data.newPassword === data.confirmPassword, {
    message: 'Passwords do not match',
    path: ['confirmPassword'],
});
exports.userSchema = zod_1.z.object({
    username: requiredText('Username', 60),
    fullName: requiredText('Full name', 120),
    role: zod_1.z.enum(constants_1.USER_ROLES).default('ADMIN'),
    password: zod_1.z.string().min(8, 'Use at least 8 characters').max(200).optional(),
    active: zod_1.z.coerce.boolean().default(true),
});
// ------------------------------------------------------------------ leads
exports.leadSchema = zod_1.z.object({
    name: requiredText('Name', 120),
    phone,
    email: optionalEmail,
    source: zod_1.z.enum(constants_1.LEAD_SOURCES).default('WALK_IN'),
    budget: money.default(0),
    interestedPropertyId: optionalId,
    projectId: optionalId,
    followUpDate: optionalDate,
    status: zod_1.z.enum(constants_1.LEAD_STATUSES).default('NEW'),
    assignedTo: optionalText,
    notes: optionalText,
});
exports.leadActivitySchema = zod_1.z.object({
    type: zod_1.z.enum(constants_1.LEAD_ACTIVITY_TYPES).default('NOTE'),
    detail: requiredText('Detail', 2000),
    happenedOn: dateValue.default(() => new Date()),
});
exports.convertLeadSchema = zod_1.z.object({
    address: optionalText,
    panNo: optionalText,
    createBooking: zod_1.z.coerce.boolean().default(false),
    propertyId: optionalId,
    agreementValue: money.default(0),
    bookingAmount: money.default(0),
});
// ------------------------------------------------------------------ clients
exports.clientSchema = zod_1.z.object({
    name: requiredText('Name', 120),
    phone,
    email: optionalEmail,
    address: optionalText,
    panNo: optionalText,
    aadhaarNo: optionalText,
    notes: optionalText,
});
exports.bookingSchema = zod_1.z.object({
    clientId: zod_1.z.coerce.number().int().positive('Select a client'),
    propertyId: zod_1.z.coerce.number().int().positive('Select a property'),
    projectId: optionalId,
    bookingDate: dateValue,
    agreementValue: money.default(0),
    bookingAmount: money.default(0),
    status: zod_1.z.enum(constants_1.BOOKING_STATUSES).default('ACTIVE'),
    agreementNo: optionalText,
    notes: optionalText,
});
exports.paymentSchema = zod_1.z.object({
    clientId: zod_1.z.coerce.number().int().positive('Select a client'),
    bookingId: optionalId,
    amount: money.refine((value) => value > 0, 'Amount must be greater than zero'),
    mode: zod_1.z.enum(constants_1.PAYMENT_MODES).default('BANK'),
    paidOn: dateValue,
    reference: optionalText,
    notes: optionalText,
});
exports.interactionSchema = zod_1.z.object({
    clientId: zod_1.z.coerce.number().int().positive(),
    type: zod_1.z.enum(constants_1.INTERACTION_TYPES).default('NOTE'),
    detail: requiredText('Detail', 2000),
    happenedOn: dateValue.default(() => new Date()),
});
exports.documentSchema = zod_1.z.object({
    clientId: optionalId,
    bookingId: optionalId,
    title: requiredText('Title', 200),
    category: zod_1.z.enum(constants_1.DOCUMENT_CATEGORIES).default('AGREEMENT'),
});
// ------------------------------------------------------------------ projects
exports.projectSchema = zod_1.z.object({
    name: requiredText('Project name', 120),
    code: requiredText('Project code', 30).regex(/^[A-Za-z0-9-_]+$/, 'Use letters, numbers, - or _'),
    location: requiredText('Location', 200),
    startDate: dateValue,
    expectedEndDate: dateValue,
    actualEndDate: optionalDate,
    budget: money.default(0),
    contractor: optionalText,
    engineer: optionalText,
    status: zod_1.z.enum(constants_1.PROJECT_STATUSES).default('ACTIVE'),
    description: optionalText,
}).refine((data) => data.expectedEndDate >= data.startDate, {
    message: 'Expected end date must be on or after the start date',
    path: ['expectedEndDate'],
});
exports.stageSchema = zod_1.z.object({
    name: requiredText('Stage name', 80),
    weight: zod_1.z.coerce.number().min(0).max(100).default(1),
    progress: zod_1.z.coerce.number().min(0, 'Progress cannot be negative').max(100, 'Progress cannot exceed 100').default(0),
    sortOrder: zod_1.z.coerce.number().int().min(0).default(0),
});
exports.stageProgressSchema = zod_1.z.object({
    progress: zod_1.z.coerce.number().min(0).max(100),
    recordedOn: dateValue.default(() => new Date()),
    note: optionalText,
});
exports.milestoneSchema = zod_1.z.object({
    projectId: zod_1.z.coerce.number().int().positive('Select a project'),
    title: requiredText('Title', 200),
    dueDate: dateValue,
    completedOn: optionalDate,
    status: zod_1.z.enum(constants_1.MILESTONE_STATUSES).default('PENDING'),
    notes: optionalText,
});
// ------------------------------------------------------------------ properties
exports.propertySchema = zod_1.z.object({
    projectId: zod_1.z.coerce.number().int().positive('Select a project'),
    tower: requiredText('Tower', 40),
    floor: zod_1.z.coerce.number().int().min(-5).max(200),
    unit: requiredText('Unit', 40),
    unitType: zod_1.z.enum(constants_1.UNIT_TYPES).default('2BHK'),
    sizeSqft: quantity.default(0),
    price: money.default(0),
    facing: zod_1.z.enum(constants_1.PROPERTY_FACINGS).default('EAST'),
    status: zod_1.z.enum(constants_1.PROPERTY_STATUSES).default('AVAILABLE'),
    notes: optionalText,
});
exports.propertyImportSchema = zod_1.z.object({
    rows: zod_1.z.array(exports.propertySchema).min(1, 'Nothing to import').max(5000),
});
// ------------------------------------------------------------------ inventory
exports.materialSchema = zod_1.z.object({
    name: requiredText('Material name', 120),
    category: zod_1.z.enum(constants_1.MATERIAL_CATEGORIES).default('GENERAL'),
    unit: requiredText('Unit', 20),
    openingStock: quantity.default(0),
    reorderLevel: quantity.default(0),
    rate: money.default(0),
    active: zod_1.z.coerce.boolean().default(true),
});
exports.purchaseSchema = zod_1.z.object({
    materialId: zod_1.z.coerce.number().int().positive('Select a material'),
    projectId: optionalId,
    quantity: quantity.refine((value) => value > 0, 'Quantity must be greater than zero'),
    rate: money,
    supplier: optionalText,
    invoiceNo: optionalText,
    purchasedOn: dateValue,
    notes: optionalText,
});
exports.materialUsageSchema = zod_1.z.object({
    materialId: zod_1.z.coerce.number().int().positive('Select a material'),
    projectId: zod_1.z.coerce.number().int().positive('Select a project'),
    quantity: quantity.refine((value) => value > 0, 'Quantity must be greater than zero'),
    usedOn: dateValue,
    issuedTo: optionalText,
    notes: optionalText,
});
exports.stockAdjustmentSchema = zod_1.z.object({
    materialId: zod_1.z.coerce.number().int().positive('Select a material'),
    quantity: zod_1.z.coerce.number().refine((value) => value !== 0, 'Quantity cannot be zero'),
    reason: zod_1.z.enum(constants_1.STOCK_ADJUSTMENT_REASONS).default('RETURN'),
    adjustedOn: dateValue,
    notes: optionalText,
});
// ------------------------------------------------------------------ labour
exports.workerSchema = zod_1.z.object({
    name: requiredText('Worker name', 120),
    mobile: phone.optional().nullable().or(zod_1.z.literal('')).transform((value) => (value ? value : null)),
    skill: zod_1.z.enum(constants_1.WORKER_SKILLS).default('HELPER'),
    contractor: optionalText,
    dailyWage: money.default(0),
    projectId: optionalId,
    active: zod_1.z.coerce.boolean().default(true),
    joinedOn: dateValue.default(() => new Date()),
});
exports.attendanceEntrySchema = zod_1.z.object({
    workerId: zod_1.z.coerce.number().int().positive(),
    status: zod_1.z.enum(constants_1.ATTENDANCE_STATUSES).default('PRESENT'),
    overtimeHours: zod_1.z.coerce.number().min(0).max(16).default(0),
    notes: optionalText,
});
/** The attendance screen saves a whole day for a site in one request. */
exports.attendanceDaySchema = zod_1.z.object({
    markedOn: dateValue,
    projectId: optionalId,
    entries: zod_1.z.array(exports.attendanceEntrySchema).max(2000),
});
// ------------------------------------------------------------------ dpr
exports.dprMaterialSchema = zod_1.z.object({
    materialId: zod_1.z.coerce.number().int().positive(),
    quantity: quantity.refine((value) => value > 0, 'Quantity must be greater than zero'),
});
exports.dprSchema = zod_1.z.object({
    projectId: zod_1.z.coerce.number().int().positive('Select a project'),
    reportDate: dateValue,
    weather: zod_1.z.enum(constants_1.WEATHER_OPTIONS).default('CLEAR'),
    workCompleted: requiredText('Work completed', 5000),
    labourCount: zod_1.z.coerce.number().int().min(0).max(100000).default(0),
    machinery: optionalText,
    siteIssues: optionalText,
    safetyNotes: optionalText,
    preparedBy: optionalText,
    materials: zod_1.z.array(exports.dprMaterialSchema).max(100).default([]),
    /** When true the materials listed are also booked out of stock. */
    deductStock: zod_1.z.coerce.boolean().default(false),
});
// ------------------------------------------------------------------ settings
exports.settingsSchema = zod_1.z.object({
    companyName: requiredText('Company name', 120),
    companyAddress: optionalText,
    companyPhone: optionalText,
    companyEmail: optionalEmail,
    gstNo: optionalText,
    currency: zod_1.z.string().trim().min(1).max(5).default('₹'),
    financialYearStart: zod_1.z.string().regex(/^\d{2}-\d{2}$/, 'Use MM-DD').default('04-01'),
    lowStockAlerts: zod_1.z.coerce.boolean().default(true),
    followUpReminderDays: zod_1.z.coerce.number().int().min(0).max(30).default(3),
});
// ------------------------------------------------------------------ queries
exports.listQuerySchema = zod_1.z.object({
    q: zod_1.z.string().trim().max(200).optional(),
    page: zod_1.z.coerce.number().int().min(1).default(1),
    pageSize: zod_1.z.coerce.number().int().min(1).max(500).default(25),
    sortBy: zod_1.z.string().trim().max(60).optional(),
    sortDir: zod_1.z.enum(['asc', 'desc']).default('desc'),
    from: zod_1.z.coerce.date().optional(),
    to: zod_1.z.coerce.date().optional(),
    status: zod_1.z.string().trim().max(60).optional(),
    projectId: zod_1.z.coerce.number().int().positive().optional(),
    materialId: zod_1.z.coerce.number().int().positive().optional(),
    clientId: zod_1.z.coerce.number().int().positive().optional(),
    workerId: zod_1.z.coerce.number().int().positive().optional(),
    category: zod_1.z.string().trim().max(60).optional(),
    skill: zod_1.z.string().trim().max(60).optional(),
    source: zod_1.z.string().trim().max(60).optional(),
});
//# sourceMappingURL=schemas.js.map