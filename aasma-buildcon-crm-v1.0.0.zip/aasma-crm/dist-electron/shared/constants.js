"use strict";
/**
 * Single source of truth for the fixed value lists used by the CRM.
 *
 * SQLite has no native enum type, so these arrays back both the Zod validation
 * on the server and the dropdowns/badges in the React app. Adding a value here
 * makes it legal everywhere at once.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.RISK_COLORS = exports.CHART_COLORS = exports.BRAND = exports.RISK_LEVELS = exports.USER_ROLES = exports.INTERACTION_TYPES = exports.DOCUMENT_CATEGORIES = exports.BOOKING_STATUSES = exports.PAYMENT_MODES = exports.WEATHER_OPTIONS = exports.ATTENDANCE_WEIGHT = exports.ATTENDANCE_STATUSES = exports.WORKER_SKILLS = exports.STOCK_ADJUSTMENT_REASONS = exports.MATERIAL_CATEGORIES = exports.MILESTONE_STATUSES = exports.DEFAULT_STAGES = exports.PROJECT_STATUSES = exports.UNIT_TYPES = exports.PROPERTY_FACINGS = exports.PROPERTY_STATUSES = exports.LEAD_ACTIVITY_TYPES = exports.LEAD_SOURCES = exports.LEAD_STATUSES = void 0;
exports.humanize = humanize;
exports.LEAD_STATUSES = [
    'NEW',
    'CONTACTED',
    'INTERESTED',
    'SITE_VISIT',
    'NEGOTIATION',
    'WON',
    'LOST',
];
exports.LEAD_SOURCES = [
    'WALK_IN',
    'REFERRAL',
    'WEBSITE',
    'CALL',
    'BROKER',
    'CAMPAIGN',
];
exports.LEAD_ACTIVITY_TYPES = ['NOTE', 'CALL', 'VISIT', 'STATUS_CHANGE', 'EMAIL'];
exports.PROPERTY_STATUSES = ['AVAILABLE', 'RESERVED', 'SOLD'];
exports.PROPERTY_FACINGS = ['EAST', 'WEST', 'NORTH', 'SOUTH', 'NORTH_EAST', 'SOUTH_EAST', 'NORTH_WEST', 'SOUTH_WEST'];
exports.UNIT_TYPES = ['1BHK', '2BHK', '3BHK', '4BHK', 'PENTHOUSE', 'SHOP', 'OFFICE', 'PLOT'];
exports.PROJECT_STATUSES = ['PLANNED', 'ACTIVE', 'ON_HOLD', 'COMPLETED'];
/** The default construction stages every new project is created with. */
exports.DEFAULT_STAGES = [
    { name: 'Foundation', weight: 15 },
    { name: 'Structure', weight: 25 },
    { name: 'Brick Work', weight: 15 },
    { name: 'Plaster', weight: 10 },
    { name: 'Electrical', weight: 10 },
    { name: 'Plumbing', weight: 10 },
    { name: 'Finishing', weight: 15 },
];
exports.MILESTONE_STATUSES = ['PENDING', 'DONE', 'DELAYED'];
exports.MATERIAL_CATEGORIES = [
    'CEMENT',
    'SAND',
    'STEEL',
    'BRICKS',
    'GRAVEL',
    'PAINT',
    'PIPES',
    'ELECTRICAL',
    'GENERAL',
];
exports.STOCK_ADJUSTMENT_REASONS = ['RETURN', 'DAMAGE', 'WASTAGE', 'CORRECTION'];
exports.WORKER_SKILLS = [
    'MASON',
    'CARPENTER',
    'ELECTRICIAN',
    'PLUMBER',
    'PAINTER',
    'HELPER',
    'OPERATOR',
    'SUPERVISOR',
];
exports.ATTENDANCE_STATUSES = ['PRESENT', 'HALF_DAY', 'ABSENT'];
/** Day-value each attendance status contributes to a labour-day total. */
exports.ATTENDANCE_WEIGHT = {
    PRESENT: 1,
    HALF_DAY: 0.5,
    ABSENT: 0,
};
exports.WEATHER_OPTIONS = ['CLEAR', 'CLOUDY', 'RAIN', 'STORM', 'HOT'];
exports.PAYMENT_MODES = ['CASH', 'BANK', 'CHEQUE', 'UPI', 'LOAN'];
exports.BOOKING_STATUSES = ['ACTIVE', 'CANCELLED', 'COMPLETED'];
exports.DOCUMENT_CATEGORIES = ['AGREEMENT', 'KYC', 'RECEIPT', 'PLAN', 'OTHER'];
exports.INTERACTION_TYPES = ['NOTE', 'CALL', 'MEETING', 'SITE_VISIT', 'PAYMENT', 'DOCUMENT'];
exports.USER_ROLES = ['ADMIN', 'MANAGER', 'ENGINEER'];
exports.RISK_LEVELS = ['GREEN', 'YELLOW', 'RED'];
/** Turns SCREAMING_SNAKE codes into "Screaming Snake" for display. */
function humanize(value) {
    if (!value)
        return '—';
    return value
        .toLowerCase()
        .split('_')
        .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ');
}
/** Brand palette from the Aasma Construction guidelines. */
exports.BRAND = {
    crimson: '#BC1F43',
    accent: '#EE3A43',
    mist: '#C7C8CA',
    steel: '#818286',
    ink: '#231F20',
};
/** Ordered series colours for charts — brand first, then supporting hues. */
exports.CHART_COLORS = [
    '#BC1F43',
    '#EE3A43',
    '#818286',
    '#E7899A',
    '#C7C8CA',
    '#7A1230',
    '#F2A9AE',
    '#4B4749',
];
exports.RISK_COLORS = {
    GREEN: '#15803D',
    YELLOW: '#B45309',
    RED: '#BC1F43',
};
//# sourceMappingURL=constants.js.map