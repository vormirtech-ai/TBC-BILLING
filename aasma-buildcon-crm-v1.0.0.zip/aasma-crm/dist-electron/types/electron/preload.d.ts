/**
 * The only bridge between the page and the desktop shell. Nothing from Node is
 * exposed directly — just three named actions the Settings screen uses.
 */
declare const api: {
    isDesktop: boolean;
    info: () => Promise<{
        version: string;
        platform: string;
        dataFolder: string;
        apiUrl: string;
    }>;
    openFolder: (kind: "data" | "backups" | "reports" | "uploads") => Promise<{
        ok: boolean;
        error: string;
    }>;
    restart: () => Promise<void>;
};
export type AasmaBridge = typeof api;
export {};
