import ExcelJS from 'exceljs';
import type { ReportResult } from './report.service';
import type { AppSettings } from '../lib/settings';
/**
 * Renders a report as a formatted workbook: branded header block, frozen and
 * filtered column headings, typed cells (so Excel can sum and sort them) and a
 * bold totals row.
 */
export declare function reportToWorkbook(report: ReportResult, settings: AppSettings): Promise<ExcelJS.Workbook>;
export declare function workbookBuffer(workbook: ExcelJS.Workbook): Promise<Buffer>;
export declare function reportFileName(report: ReportResult): string;
