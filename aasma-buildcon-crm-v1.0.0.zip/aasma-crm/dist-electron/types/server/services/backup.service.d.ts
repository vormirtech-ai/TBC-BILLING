import type { BackupFile } from '../../shared/types';
/**
 * Backups are a straight file copy of the SQLite database. `VACUUM INTO` is used
 * so the copy is a consistent, compacted snapshot even while the app is running
 * and the write-ahead log has uncommitted pages.
 */
export declare function createBackup(): Promise<BackupFile>;
export declare function listBackups(): BackupFile[];
export declare function backupPath(name: string): string;
/**
 * Restores a backup over the live database. The current database is copied to a
 * "pre-restore" backup first, so a mistaken restore is itself recoverable. The
 * caller is expected to restart the app afterwards.
 */
export declare function restoreBackup(name: string): Promise<{
    restoredFrom: string;
    safetyCopy: string;
}>;
export declare function deleteBackup(name: string): void;
export declare function importBackupFile(tempPath: string, originalName: string): BackupFile;
