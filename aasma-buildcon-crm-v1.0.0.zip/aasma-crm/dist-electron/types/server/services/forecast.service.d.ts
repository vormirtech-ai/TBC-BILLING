import type { ProjectForecast } from '../../shared/types';
export declare function buildForecast(projectId: number, today?: Date): Promise<ProjectForecast | null>;
export declare function buildAllForecasts(): Promise<ProjectForecast[]>;
/** Stores the current forecast so trends can be charted later. */
export declare function saveForecastSnapshot(forecast: ProjectForecast): Promise<void>;
