import type { ListQuery } from '../../shared/schemas';
import type { ReportDefinition } from '../../shared/types';
export type ColumnType = 'text' | 'number' | 'money' | 'date' | 'percent';
export interface ReportColumn {
    key: string;
    header: string;
    type?: ColumnType;
    width?: number;
}
export interface ReportResult {
    key: string;
    title: string;
    subtitle: string;
    columns: ReportColumn[];
    rows: Record<string, unknown>[];
    /** Column key → total, rendered as a bold last row in Excel. */
    totals: Record<string, number>;
}
/** Everything the Reports screen offers, and which filters each one honours. */
export declare const REPORTS: ReportDefinition[];
export declare function buildReport(key: string, query: ListQuery): Promise<ReportResult>;
