import type { DashboardCharts, DashboardSummary } from '../../shared/types';
export declare function getDashboardSummary(today?: Date): Promise<DashboardSummary>;
export declare function getDashboardCharts(today?: Date): Promise<DashboardCharts>;
