import type { StockRow } from '../../shared/types';
/**
 * Live stock is never stored as a column — it is derived from opening stock plus
 * purchases, minus issues, plus adjustments. Deriving it keeps the ledger and
 * the balance from ever drifting apart.
 */
export declare function getStockRows(filter?: {
    category?: string;
    q?: string;
}): Promise<StockRow[]>;
export declare function getStockForMaterial(materialId: number): Promise<StockRow | null>;
export declare function getLowStockRows(): Promise<StockRow[]>;
