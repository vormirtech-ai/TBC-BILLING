export interface RunningServer {
    port: number;
    url: string;
    stop: () => Promise<void>;
}
/**
 * Starts the API on the first free port from the preferred one upwards, so a
 * second copy of the app (or an unrelated service) cannot stop it from opening.
 */
export declare function startServer(preferredPort?: number): Promise<RunningServer>;
