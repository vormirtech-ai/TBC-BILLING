import { type Express } from 'express';
/**
 * The whole API. It only ever listens on the loopback interface, so nothing on
 * the network can reach it — this is a single-machine application.
 */
export declare function createApp(): Express;
