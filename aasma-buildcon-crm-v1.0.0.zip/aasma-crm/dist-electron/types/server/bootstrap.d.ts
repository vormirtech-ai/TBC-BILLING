/**
 * Makes sure there is a usable database before the API accepts a request.
 *
 * Three situations, in order of preference:
 *   1. The database already exists — nothing to do.
 *   2. A template database was shipped with the build — copy it. This is how a
 *      packaged install starts up on a machine with no toolchain and no network.
 *   3. Neither — run `prisma db push` from the local node_modules (development
 *      and "run from source" installs).
 */
export declare function ensureDatabase(): void;
export declare const DEFAULT_ADMIN: {
    username: string;
    password: string;
};
/** Creates the first administrator so a fresh install can be signed into. */
export declare function ensureAdminUser(): Promise<void>;
export declare function prepareDatabase(): Promise<void>;
