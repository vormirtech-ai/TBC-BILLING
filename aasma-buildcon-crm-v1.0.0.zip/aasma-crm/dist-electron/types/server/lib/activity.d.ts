/**
 * Best-effort audit trail. A logging failure must never fail the user's action,
 * so errors here are swallowed after being reported to the console.
 */
export declare function logActivity(input: {
    actor: string;
    action: string;
    entity: string;
    entityId?: string | number | null;
    detail?: string | null;
}): Promise<void>;
