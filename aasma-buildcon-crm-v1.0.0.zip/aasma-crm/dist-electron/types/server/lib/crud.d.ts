import { Router } from 'express';
import type { ZodTypeAny } from 'zod';
import { type Where } from './query';
import type { ListQuery } from '../../shared/schemas';
/**
 * The subset of a Prisma model delegate this factory needs. Prisma generates a
 * differently-typed delegate per model, so the shared shape is declared here
 * rather than fighting the generated generics.
 */
export interface Delegate {
    findMany(args?: any): Promise<any[]>;
    count(args?: any): Promise<number>;
    findUnique(args: any): Promise<any | null>;
    create(args: any): Promise<any>;
    update(args: any): Promise<any>;
    delete(args: any): Promise<any>;
}
export interface CrudOptions {
    delegate: Delegate;
    /** Human label used in messages and the audit log, e.g. "Lead". */
    entity: string;
    schema: ZodTypeAny;
    /** Schema used for updates when it differs from the create schema. */
    updateSchema?: ZodTypeAny;
    searchFields?: string[];
    sortable?: string[];
    defaultSort?: string;
    /** Column the ?from / ?to filters apply to. */
    dateField?: string;
    /** Relations to load for a list request. */
    listInclude?: any;
    /** Relations to load for a single record. */
    detailInclude?: any;
    /** Extra where-clause built from the query string. */
    filters?: (query: ListQuery) => Where | null;
    /** Maps validated input onto the Prisma data object. */
    toData?: (input: any, mode: 'create' | 'update') => any;
    /** Runs inside the request, after the row is written. */
    afterWrite?: (row: any, mode: 'create' | 'update', actor: string) => Promise<void>;
    /** Runs before a delete; throw to block it. */
    beforeDelete?: (id: number) => Promise<void>;
}
/**
 * Builds the five routes every master screen needs. Each resource still owns
 * its validation, filters and relations — only the plumbing is shared.
 */
export declare function crudRouter(options: CrudOptions): Router;
