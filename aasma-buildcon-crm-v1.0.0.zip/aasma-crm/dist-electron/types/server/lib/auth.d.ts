import type { NextFunction, Request, Response } from 'express';
import type { AuthUser } from '../../shared/types';
/**
 * The signing secret is generated on first run and kept in the local database,
 * so a copied install cannot reuse another machine's tokens. There is no login
 * server involved — the whole exchange happens inside this process.
 */
export declare function getSecret(): Promise<string>;
export declare function hashPassword(plain: string): Promise<string>;
export declare function verifyPassword(plain: string, hash: string): Promise<boolean>;
export declare function issueToken(user: AuthUser): Promise<string>;
export interface AuthedRequest extends Request {
    user?: AuthUser;
}
/** Rejects anything without a valid, unexpired token for an active user. */
export declare function requireAuth(req: AuthedRequest, _res: Response, next: NextFunction): Promise<void>;
/** Route guard for actions only an administrator may perform. */
export declare function requireRole(...roles: string[]): (req: AuthedRequest, _res: Response, next: NextFunction) => void;
