import { PrismaClient } from '@prisma/client';
/**
 * One Prisma client for the whole process. The datasource URL is set here at
 * runtime rather than from .env, because the packaged app keeps its database in
 * Electron's userData folder.
 */
export declare const prisma: PrismaClient<{
    datasources: {
        db: {
            url: string;
        };
    };
    log: ("warn" | "error")[];
}, "warn" | "error", import("@prisma/client/runtime/library").DefaultArgs>;
export declare function disconnectPrisma(): Promise<void>;
/**
 * SQLite performs far better for this workload with write-ahead logging on.
 * `PRAGMA journal_mode` answers with a row, so these go through $queryRawUnsafe;
 * a pragma a particular build refuses is not worth failing start-up over.
 */
export declare function tuneSqlite(): Promise<void>;
