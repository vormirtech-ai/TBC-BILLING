import type { NextFunction, Request, Response } from 'express';
/** An error with an HTTP status the API is happy to show the user. */
export declare class HttpError extends Error {
    readonly status: number;
    readonly details?: {
        path: string;
        message: string;
    }[] | undefined;
    constructor(status: number, message: string, details?: {
        path: string;
        message: string;
    }[] | undefined);
}
export declare const badRequest: (message: string) => HttpError;
export declare const unauthorized: (message?: string) => HttpError;
export declare const notFound: (what?: string) => HttpError;
export declare const conflict: (message: string) => HttpError;
/** Wraps an async route so a rejected promise reaches the error middleware. */
export declare function asyncHandler<T extends Request>(handler: (req: T, res: Response, next: NextFunction) => Promise<unknown>): (req: Request, res: Response, next: NextFunction) => void;
/**
 * Turns anything thrown inside a route into a predictable JSON body. The app
 * must never crash on bad input, so unknown failures become a 500 with a plain
 * message rather than an unhandled rejection.
 */
export declare function errorMiddleware(error: unknown, _req: Request, res: Response, _next: NextFunction): void;
