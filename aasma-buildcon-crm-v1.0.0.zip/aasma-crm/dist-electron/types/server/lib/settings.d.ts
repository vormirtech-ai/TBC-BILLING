import { settingsSchema, type SettingsInput } from '../../shared/schemas';
export type AppSettings = ReturnType<typeof settingsSchema.parse>;
export declare const DEFAULT_SETTINGS: AppSettings;
export declare function getSettings(): Promise<AppSettings>;
export declare function saveSettings(input: SettingsInput): Promise<AppSettings>;
