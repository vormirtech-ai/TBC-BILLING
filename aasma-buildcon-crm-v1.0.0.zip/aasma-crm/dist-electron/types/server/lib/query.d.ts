import type { Request } from 'express';
import { type ListQuery } from '../../shared/schemas';
import type { Paginated } from '../../shared/types';
export type Where = Record<string, unknown>;
export declare function parseListQuery(req: Request): ListQuery;
/**
 * Text search across the given columns. SQLite's LIKE is case-insensitive for
 * ASCII, which is what `contains` compiles to, so no extra collation is needed.
 */
export declare function searchFilter(term: string | undefined, fields: string[]): Where | null;
/** Inclusive from/to filter on a date column. */
export declare function dateFilter(field: string, from?: Date, to?: Date): Where | null;
export declare function combine(...parts: (Where | null | undefined)[]): Where;
/** Only ever sort by a column we have explicitly allowed. */
export declare function orderBy(query: ListQuery, allowed: string[], fallback: string): Record<string, 'asc' | 'desc'>;
export declare function paginate(query: ListQuery): {
    skip: number;
    take: number;
};
export declare function toPage<T>(rows: T[], total: number, query: ListQuery): Paginated<T>;
export declare function startOfDay(date: Date): Date;
export declare function endOfDay(date: Date): Date;
export declare function addDays(date: Date, days: number): Date;
export declare function daysBetween(from: Date, to: Date): number;
export declare function round(value: number, decimals?: number): number;
