export declare const APP_ROOT: string;
/** Writable root. Electron overrides this with its userData folder. */
export declare const DATA_ROOT: string;
export declare const PATHS: {
    appRoot: string;
    dataRoot: string;
    dataDir: string;
    backupsDir: string;
    uploadsDir: string;
    reportsDir: string;
    databaseFile: string;
    /** Empty database shipped with the build, copied on first run. */
    templateDatabase: string;
    schemaFile: string;
    rendererDir: string;
};
export declare function ensureDirectories(): void;
export declare function databaseUrl(): string;
