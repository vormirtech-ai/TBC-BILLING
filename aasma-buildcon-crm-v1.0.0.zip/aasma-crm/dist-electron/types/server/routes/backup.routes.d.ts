export declare const backupRouter: import("express-serve-static-core").Router;
