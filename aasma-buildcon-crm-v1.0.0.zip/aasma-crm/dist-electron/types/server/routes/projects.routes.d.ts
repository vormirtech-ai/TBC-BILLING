export declare const projectsRouter: import("express-serve-static-core").Router;
export declare const milestonesRouter: import("express-serve-static-core").Router;
