export declare const materialsRouter: import("express-serve-static-core").Router;
export declare const purchasesRouter: import("express-serve-static-core").Router;
export declare const usageRouter: import("express-serve-static-core").Router;
export declare const adjustmentsRouter: import("express-serve-static-core").Router;
