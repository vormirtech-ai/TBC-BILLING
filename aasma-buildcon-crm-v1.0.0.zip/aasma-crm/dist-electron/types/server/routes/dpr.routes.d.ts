export declare const dprRouter: import("express-serve-static-core").Router;
