export declare const workersRouter: import("express-serve-static-core").Router;
export declare const attendanceRouter: import("express-serve-static-core").Router;
