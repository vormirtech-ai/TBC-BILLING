export declare const forecastRouter: import("express-serve-static-core").Router;
