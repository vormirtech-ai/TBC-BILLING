export declare const clientsRouter: import("express-serve-static-core").Router;
export declare const bookingsRouter: import("express-serve-static-core").Router;
export declare const paymentsRouter: import("express-serve-static-core").Router;
