export declare const settingsRouter: import("express-serve-static-core").Router;
export declare const usersRouter: import("express-serve-static-core").Router;
