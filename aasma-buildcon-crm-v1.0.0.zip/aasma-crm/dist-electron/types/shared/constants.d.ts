/**
 * Single source of truth for the fixed value lists used by the CRM.
 *
 * SQLite has no native enum type, so these arrays back both the Zod validation
 * on the server and the dropdowns/badges in the React app. Adding a value here
 * makes it legal everywhere at once.
 */
export declare const LEAD_STATUSES: readonly ["NEW", "CONTACTED", "INTERESTED", "SITE_VISIT", "NEGOTIATION", "WON", "LOST"];
export type LeadStatus = (typeof LEAD_STATUSES)[number];
export declare const LEAD_SOURCES: readonly ["WALK_IN", "REFERRAL", "WEBSITE", "CALL", "BROKER", "CAMPAIGN"];
export type LeadSource = (typeof LEAD_SOURCES)[number];
export declare const LEAD_ACTIVITY_TYPES: readonly ["NOTE", "CALL", "VISIT", "STATUS_CHANGE", "EMAIL"];
export declare const PROPERTY_STATUSES: readonly ["AVAILABLE", "RESERVED", "SOLD"];
export type PropertyStatus = (typeof PROPERTY_STATUSES)[number];
export declare const PROPERTY_FACINGS: readonly ["EAST", "WEST", "NORTH", "SOUTH", "NORTH_EAST", "SOUTH_EAST", "NORTH_WEST", "SOUTH_WEST"];
export declare const UNIT_TYPES: readonly ["1BHK", "2BHK", "3BHK", "4BHK", "PENTHOUSE", "SHOP", "OFFICE", "PLOT"];
export declare const PROJECT_STATUSES: readonly ["PLANNED", "ACTIVE", "ON_HOLD", "COMPLETED"];
export type ProjectStatus = (typeof PROJECT_STATUSES)[number];
/** The default construction stages every new project is created with. */
export declare const DEFAULT_STAGES: readonly [{
    readonly name: "Foundation";
    readonly weight: 15;
}, {
    readonly name: "Structure";
    readonly weight: 25;
}, {
    readonly name: "Brick Work";
    readonly weight: 15;
}, {
    readonly name: "Plaster";
    readonly weight: 10;
}, {
    readonly name: "Electrical";
    readonly weight: 10;
}, {
    readonly name: "Plumbing";
    readonly weight: 10;
}, {
    readonly name: "Finishing";
    readonly weight: 15;
}];
export declare const MILESTONE_STATUSES: readonly ["PENDING", "DONE", "DELAYED"];
export declare const MATERIAL_CATEGORIES: readonly ["CEMENT", "SAND", "STEEL", "BRICKS", "GRAVEL", "PAINT", "PIPES", "ELECTRICAL", "GENERAL"];
export type MaterialCategory = (typeof MATERIAL_CATEGORIES)[number];
export declare const STOCK_ADJUSTMENT_REASONS: readonly ["RETURN", "DAMAGE", "WASTAGE", "CORRECTION"];
export declare const WORKER_SKILLS: readonly ["MASON", "CARPENTER", "ELECTRICIAN", "PLUMBER", "PAINTER", "HELPER", "OPERATOR", "SUPERVISOR"];
export type WorkerSkill = (typeof WORKER_SKILLS)[number];
export declare const ATTENDANCE_STATUSES: readonly ["PRESENT", "HALF_DAY", "ABSENT"];
export type AttendanceStatus = (typeof ATTENDANCE_STATUSES)[number];
/** Day-value each attendance status contributes to a labour-day total. */
export declare const ATTENDANCE_WEIGHT: Record<AttendanceStatus, number>;
export declare const WEATHER_OPTIONS: readonly ["CLEAR", "CLOUDY", "RAIN", "STORM", "HOT"];
export declare const PAYMENT_MODES: readonly ["CASH", "BANK", "CHEQUE", "UPI", "LOAN"];
export declare const BOOKING_STATUSES: readonly ["ACTIVE", "CANCELLED", "COMPLETED"];
export declare const DOCUMENT_CATEGORIES: readonly ["AGREEMENT", "KYC", "RECEIPT", "PLAN", "OTHER"];
export declare const INTERACTION_TYPES: readonly ["NOTE", "CALL", "MEETING", "SITE_VISIT", "PAYMENT", "DOCUMENT"];
export declare const USER_ROLES: readonly ["ADMIN", "MANAGER", "ENGINEER"];
export type UserRole = (typeof USER_ROLES)[number];
export declare const RISK_LEVELS: readonly ["GREEN", "YELLOW", "RED"];
export type RiskLevel = (typeof RISK_LEVELS)[number];
/** Turns SCREAMING_SNAKE codes into "Screaming Snake" for display. */
export declare function humanize(value: string | null | undefined): string;
/** Brand palette from the Aasma Construction guidelines. */
export declare const BRAND: {
    readonly crimson: "#BC1F43";
    readonly accent: "#EE3A43";
    readonly mist: "#C7C8CA";
    readonly steel: "#818286";
    readonly ink: "#231F20";
};
/** Ordered series colours for charts — brand first, then supporting hues. */
export declare const CHART_COLORS: readonly ["#BC1F43", "#EE3A43", "#818286", "#E7899A", "#C7C8CA", "#7A1230", "#F2A9AE", "#4B4749"];
export declare const RISK_COLORS: Record<RiskLevel, string>;
