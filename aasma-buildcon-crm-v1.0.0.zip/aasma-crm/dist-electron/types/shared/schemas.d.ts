/**
 * Zod schemas shared by the Express API and the React forms.
 *
 * The server treats these as the trust boundary: nothing reaches Prisma without
 * passing through one of them. The client reuses the same schema in React Hook
 * Form, so a field can never be valid in the browser and rejected on the server.
 */
import { z } from 'zod';
export declare const loginSchema: z.ZodObject<{
    username: z.ZodString;
    password: z.ZodString;
}, "strip", z.ZodTypeAny, {
    username: string;
    password: string;
}, {
    username: string;
    password: string;
}>;
export declare const changePasswordSchema: z.ZodEffects<z.ZodObject<{
    currentPassword: z.ZodString;
    newPassword: z.ZodString;
    confirmPassword: z.ZodString;
}, "strip", z.ZodTypeAny, {
    currentPassword: string;
    newPassword: string;
    confirmPassword: string;
}, {
    currentPassword: string;
    newPassword: string;
    confirmPassword: string;
}>, {
    currentPassword: string;
    newPassword: string;
    confirmPassword: string;
}, {
    currentPassword: string;
    newPassword: string;
    confirmPassword: string;
}>;
export declare const userSchema: z.ZodObject<{
    username: z.ZodString;
    fullName: z.ZodString;
    role: z.ZodDefault<z.ZodEnum<["ADMIN", "MANAGER", "ENGINEER"]>>;
    password: z.ZodOptional<z.ZodString>;
    active: z.ZodDefault<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    role: "ADMIN" | "MANAGER" | "ENGINEER";
    active: boolean;
    username: string;
    fullName: string;
    password?: string | undefined;
}, {
    username: string;
    fullName: string;
    role?: "ADMIN" | "MANAGER" | "ENGINEER" | undefined;
    active?: boolean | undefined;
    password?: string | undefined;
}>;
export declare const leadSchema: z.ZodObject<{
    name: z.ZodString;
    phone: z.ZodString;
    email: z.ZodEffects<z.ZodUnion<[z.ZodNullable<z.ZodOptional<z.ZodString>>, z.ZodLiteral<"">]>, string | null, string | null | undefined>;
    source: z.ZodDefault<z.ZodEnum<["WALK_IN", "REFERRAL", "WEBSITE", "CALL", "BROKER", "CAMPAIGN"]>>;
    budget: z.ZodDefault<z.ZodNumber>;
    interestedPropertyId: z.ZodNullable<z.ZodOptional<z.ZodNumber>>;
    projectId: z.ZodNullable<z.ZodOptional<z.ZodNumber>>;
    followUpDate: z.ZodEffects<z.ZodEffects<z.ZodOptional<z.ZodNullable<z.ZodUnion<[z.ZodString, z.ZodDate]>>>, Date | null, string | Date | null | undefined>, Date | null, string | Date | null | undefined>;
    status: z.ZodDefault<z.ZodEnum<["NEW", "CONTACTED", "INTERESTED", "SITE_VISIT", "NEGOTIATION", "WON", "LOST"]>>;
    assignedTo: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
    notes: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
}, "strip", z.ZodTypeAny, {
    status: "SITE_VISIT" | "NEW" | "CONTACTED" | "INTERESTED" | "NEGOTIATION" | "WON" | "LOST";
    name: string;
    budget: number;
    notes: string | null;
    phone: string;
    email: string | null;
    source: "WALK_IN" | "REFERRAL" | "WEBSITE" | "CALL" | "BROKER" | "CAMPAIGN";
    followUpDate: Date | null;
    assignedTo: string | null;
    projectId?: number | null | undefined;
    interestedPropertyId?: number | null | undefined;
}, {
    name: string;
    phone: string;
    status?: "SITE_VISIT" | "NEW" | "CONTACTED" | "INTERESTED" | "NEGOTIATION" | "WON" | "LOST" | undefined;
    budget?: number | undefined;
    projectId?: number | null | undefined;
    notes?: string | null | undefined;
    email?: string | null | undefined;
    source?: "WALK_IN" | "REFERRAL" | "WEBSITE" | "CALL" | "BROKER" | "CAMPAIGN" | undefined;
    followUpDate?: string | Date | null | undefined;
    assignedTo?: string | null | undefined;
    interestedPropertyId?: number | null | undefined;
}>;
export declare const leadActivitySchema: z.ZodObject<{
    type: z.ZodDefault<z.ZodEnum<["NOTE", "CALL", "VISIT", "STATUS_CHANGE", "EMAIL"]>>;
    detail: z.ZodString;
    happenedOn: z.ZodDefault<z.ZodEffects<z.ZodEffects<z.ZodUnion<[z.ZodString, z.ZodDate]>, Date, string | Date>, Date, string | Date>>;
}, "strip", z.ZodTypeAny, {
    type: "CALL" | "VISIT" | "NOTE" | "STATUS_CHANGE" | "EMAIL";
    detail: string;
    happenedOn: Date;
}, {
    detail: string;
    type?: "CALL" | "VISIT" | "NOTE" | "STATUS_CHANGE" | "EMAIL" | undefined;
    happenedOn?: string | Date | undefined;
}>;
export declare const convertLeadSchema: z.ZodObject<{
    address: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
    panNo: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
    createBooking: z.ZodDefault<z.ZodBoolean>;
    propertyId: z.ZodNullable<z.ZodOptional<z.ZodNumber>>;
    agreementValue: z.ZodDefault<z.ZodNumber>;
    bookingAmount: z.ZodDefault<z.ZodNumber>;
}, "strip", z.ZodTypeAny, {
    address: string | null;
    panNo: string | null;
    agreementValue: number;
    bookingAmount: number;
    createBooking: boolean;
    propertyId?: number | null | undefined;
}, {
    address?: string | null | undefined;
    panNo?: string | null | undefined;
    agreementValue?: number | undefined;
    bookingAmount?: number | undefined;
    propertyId?: number | null | undefined;
    createBooking?: boolean | undefined;
}>;
export declare const clientSchema: z.ZodObject<{
    name: z.ZodString;
    phone: z.ZodString;
    email: z.ZodEffects<z.ZodUnion<[z.ZodNullable<z.ZodOptional<z.ZodString>>, z.ZodLiteral<"">]>, string | null, string | null | undefined>;
    address: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
    panNo: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
    aadhaarNo: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
    notes: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
}, "strip", z.ZodTypeAny, {
    name: string;
    notes: string | null;
    phone: string;
    email: string | null;
    address: string | null;
    panNo: string | null;
    aadhaarNo: string | null;
}, {
    name: string;
    phone: string;
    notes?: string | null | undefined;
    email?: string | null | undefined;
    address?: string | null | undefined;
    panNo?: string | null | undefined;
    aadhaarNo?: string | null | undefined;
}>;
export declare const bookingSchema: z.ZodObject<{
    clientId: z.ZodNumber;
    propertyId: z.ZodNumber;
    projectId: z.ZodNullable<z.ZodOptional<z.ZodNumber>>;
    bookingDate: z.ZodEffects<z.ZodEffects<z.ZodUnion<[z.ZodString, z.ZodDate]>, Date, string | Date>, Date, string | Date>;
    agreementValue: z.ZodDefault<z.ZodNumber>;
    bookingAmount: z.ZodDefault<z.ZodNumber>;
    status: z.ZodDefault<z.ZodEnum<["ACTIVE", "CANCELLED", "COMPLETED"]>>;
    agreementNo: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
    notes: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
}, "strip", z.ZodTypeAny, {
    status: "ACTIVE" | "CANCELLED" | "COMPLETED";
    notes: string | null;
    bookingDate: Date;
    agreementValue: number;
    bookingAmount: number;
    agreementNo: string | null;
    clientId: number;
    propertyId: number;
    projectId?: number | null | undefined;
}, {
    bookingDate: string | Date;
    clientId: number;
    propertyId: number;
    status?: "ACTIVE" | "CANCELLED" | "COMPLETED" | undefined;
    projectId?: number | null | undefined;
    notes?: string | null | undefined;
    agreementValue?: number | undefined;
    bookingAmount?: number | undefined;
    agreementNo?: string | null | undefined;
}>;
export declare const paymentSchema: z.ZodObject<{
    clientId: z.ZodNumber;
    bookingId: z.ZodNullable<z.ZodOptional<z.ZodNumber>>;
    amount: z.ZodEffects<z.ZodNumber, number, number>;
    mode: z.ZodDefault<z.ZodEnum<["CASH", "BANK", "CHEQUE", "UPI", "LOAN"]>>;
    paidOn: z.ZodEffects<z.ZodEffects<z.ZodUnion<[z.ZodString, z.ZodDate]>, Date, string | Date>, Date, string | Date>;
    reference: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
    notes: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
}, "strip", z.ZodTypeAny, {
    mode: "BANK" | "CHEQUE" | "UPI" | "LOAN" | "CASH";
    notes: string | null;
    clientId: number;
    amount: number;
    paidOn: Date;
    reference: string | null;
    bookingId?: number | null | undefined;
}, {
    clientId: number;
    amount: number;
    paidOn: string | Date;
    mode?: "BANK" | "CHEQUE" | "UPI" | "LOAN" | "CASH" | undefined;
    notes?: string | null | undefined;
    reference?: string | null | undefined;
    bookingId?: number | null | undefined;
}>;
export declare const interactionSchema: z.ZodObject<{
    clientId: z.ZodNumber;
    type: z.ZodDefault<z.ZodEnum<["NOTE", "CALL", "MEETING", "SITE_VISIT", "PAYMENT", "DOCUMENT"]>>;
    detail: z.ZodString;
    happenedOn: z.ZodDefault<z.ZodEffects<z.ZodEffects<z.ZodUnion<[z.ZodString, z.ZodDate]>, Date, string | Date>, Date, string | Date>>;
}, "strip", z.ZodTypeAny, {
    type: "SITE_VISIT" | "CALL" | "NOTE" | "PAYMENT" | "DOCUMENT" | "MEETING";
    clientId: number;
    detail: string;
    happenedOn: Date;
}, {
    clientId: number;
    detail: string;
    type?: "SITE_VISIT" | "CALL" | "NOTE" | "PAYMENT" | "DOCUMENT" | "MEETING" | undefined;
    happenedOn?: string | Date | undefined;
}>;
export declare const documentSchema: z.ZodObject<{
    clientId: z.ZodNullable<z.ZodOptional<z.ZodNumber>>;
    bookingId: z.ZodNullable<z.ZodOptional<z.ZodNumber>>;
    title: z.ZodString;
    category: z.ZodDefault<z.ZodEnum<["AGREEMENT", "KYC", "RECEIPT", "PLAN", "OTHER"]>>;
}, "strip", z.ZodTypeAny, {
    title: string;
    category: "AGREEMENT" | "KYC" | "RECEIPT" | "PLAN" | "OTHER";
    clientId?: number | null | undefined;
    bookingId?: number | null | undefined;
}, {
    title: string;
    clientId?: number | null | undefined;
    bookingId?: number | null | undefined;
    category?: "AGREEMENT" | "KYC" | "RECEIPT" | "PLAN" | "OTHER" | undefined;
}>;
export declare const projectSchema: z.ZodEffects<z.ZodObject<{
    name: z.ZodString;
    code: z.ZodString;
    location: z.ZodString;
    startDate: z.ZodEffects<z.ZodEffects<z.ZodUnion<[z.ZodString, z.ZodDate]>, Date, string | Date>, Date, string | Date>;
    expectedEndDate: z.ZodEffects<z.ZodEffects<z.ZodUnion<[z.ZodString, z.ZodDate]>, Date, string | Date>, Date, string | Date>;
    actualEndDate: z.ZodEffects<z.ZodEffects<z.ZodOptional<z.ZodNullable<z.ZodUnion<[z.ZodString, z.ZodDate]>>>, Date | null, string | Date | null | undefined>, Date | null, string | Date | null | undefined>;
    budget: z.ZodDefault<z.ZodNumber>;
    contractor: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
    engineer: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
    status: z.ZodDefault<z.ZodEnum<["PLANNED", "ACTIVE", "ON_HOLD", "COMPLETED"]>>;
    description: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
}, "strip", z.ZodTypeAny, {
    status: "ACTIVE" | "COMPLETED" | "PLANNED" | "ON_HOLD";
    code: string;
    name: string;
    location: string;
    startDate: Date;
    expectedEndDate: Date;
    budget: number;
    contractor: string | null;
    engineer: string | null;
    description: string | null;
    actualEndDate: Date | null;
}, {
    code: string;
    name: string;
    location: string;
    startDate: string | Date;
    expectedEndDate: string | Date;
    status?: "ACTIVE" | "COMPLETED" | "PLANNED" | "ON_HOLD" | undefined;
    budget?: number | undefined;
    contractor?: string | null | undefined;
    engineer?: string | null | undefined;
    description?: string | null | undefined;
    actualEndDate?: string | Date | null | undefined;
}>, {
    status: "ACTIVE" | "COMPLETED" | "PLANNED" | "ON_HOLD";
    code: string;
    name: string;
    location: string;
    startDate: Date;
    expectedEndDate: Date;
    budget: number;
    contractor: string | null;
    engineer: string | null;
    description: string | null;
    actualEndDate: Date | null;
}, {
    code: string;
    name: string;
    location: string;
    startDate: string | Date;
    expectedEndDate: string | Date;
    status?: "ACTIVE" | "COMPLETED" | "PLANNED" | "ON_HOLD" | undefined;
    budget?: number | undefined;
    contractor?: string | null | undefined;
    engineer?: string | null | undefined;
    description?: string | null | undefined;
    actualEndDate?: string | Date | null | undefined;
}>;
export declare const stageSchema: z.ZodObject<{
    name: z.ZodString;
    weight: z.ZodDefault<z.ZodNumber>;
    progress: z.ZodDefault<z.ZodNumber>;
    sortOrder: z.ZodDefault<z.ZodNumber>;
}, "strip", z.ZodTypeAny, {
    name: string;
    weight: number;
    progress: number;
    sortOrder: number;
}, {
    name: string;
    weight?: number | undefined;
    progress?: number | undefined;
    sortOrder?: number | undefined;
}>;
export declare const stageProgressSchema: z.ZodObject<{
    progress: z.ZodNumber;
    recordedOn: z.ZodDefault<z.ZodEffects<z.ZodEffects<z.ZodUnion<[z.ZodString, z.ZodDate]>, Date, string | Date>, Date, string | Date>>;
    note: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
}, "strip", z.ZodTypeAny, {
    progress: number;
    recordedOn: Date;
    note: string | null;
}, {
    progress: number;
    recordedOn?: string | Date | undefined;
    note?: string | null | undefined;
}>;
export declare const milestoneSchema: z.ZodObject<{
    projectId: z.ZodNumber;
    title: z.ZodString;
    dueDate: z.ZodEffects<z.ZodEffects<z.ZodUnion<[z.ZodString, z.ZodDate]>, Date, string | Date>, Date, string | Date>;
    completedOn: z.ZodEffects<z.ZodEffects<z.ZodOptional<z.ZodNullable<z.ZodUnion<[z.ZodString, z.ZodDate]>>>, Date | null, string | Date | null | undefined>, Date | null, string | Date | null | undefined>;
    status: z.ZodDefault<z.ZodEnum<["PENDING", "DONE", "DELAYED"]>>;
    notes: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
}, "strip", z.ZodTypeAny, {
    title: string;
    status: "DONE" | "DELAYED" | "PENDING";
    projectId: number;
    dueDate: Date;
    completedOn: Date | null;
    notes: string | null;
}, {
    title: string;
    projectId: number;
    dueDate: string | Date;
    status?: "DONE" | "DELAYED" | "PENDING" | undefined;
    completedOn?: string | Date | null | undefined;
    notes?: string | null | undefined;
}>;
export declare const propertySchema: z.ZodObject<{
    projectId: z.ZodNumber;
    tower: z.ZodString;
    floor: z.ZodNumber;
    unit: z.ZodString;
    unitType: z.ZodDefault<z.ZodEnum<["1BHK", "2BHK", "3BHK", "4BHK", "PENTHOUSE", "SHOP", "OFFICE", "PLOT"]>>;
    sizeSqft: z.ZodDefault<z.ZodNumber>;
    price: z.ZodDefault<z.ZodNumber>;
    facing: z.ZodDefault<z.ZodEnum<["EAST", "WEST", "NORTH", "SOUTH", "NORTH_EAST", "SOUTH_EAST", "NORTH_WEST", "SOUTH_WEST"]>>;
    status: z.ZodDefault<z.ZodEnum<["AVAILABLE", "RESERVED", "SOLD"]>>;
    notes: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
}, "strip", z.ZodTypeAny, {
    status: "SOLD" | "RESERVED" | "AVAILABLE";
    projectId: number;
    notes: string | null;
    tower: string;
    floor: number;
    unit: string;
    unitType: "2BHK" | "3BHK" | "1BHK" | "4BHK" | "PENTHOUSE" | "SHOP" | "OFFICE" | "PLOT";
    sizeSqft: number;
    price: number;
    facing: "EAST" | "WEST" | "NORTH" | "SOUTH" | "NORTH_EAST" | "SOUTH_WEST" | "SOUTH_EAST" | "NORTH_WEST";
}, {
    projectId: number;
    tower: string;
    floor: number;
    unit: string;
    status?: "SOLD" | "RESERVED" | "AVAILABLE" | undefined;
    notes?: string | null | undefined;
    unitType?: "2BHK" | "3BHK" | "1BHK" | "4BHK" | "PENTHOUSE" | "SHOP" | "OFFICE" | "PLOT" | undefined;
    sizeSqft?: number | undefined;
    price?: number | undefined;
    facing?: "EAST" | "WEST" | "NORTH" | "SOUTH" | "NORTH_EAST" | "SOUTH_WEST" | "SOUTH_EAST" | "NORTH_WEST" | undefined;
}>;
export declare const propertyImportSchema: z.ZodObject<{
    rows: z.ZodArray<z.ZodObject<{
        projectId: z.ZodNumber;
        tower: z.ZodString;
        floor: z.ZodNumber;
        unit: z.ZodString;
        unitType: z.ZodDefault<z.ZodEnum<["1BHK", "2BHK", "3BHK", "4BHK", "PENTHOUSE", "SHOP", "OFFICE", "PLOT"]>>;
        sizeSqft: z.ZodDefault<z.ZodNumber>;
        price: z.ZodDefault<z.ZodNumber>;
        facing: z.ZodDefault<z.ZodEnum<["EAST", "WEST", "NORTH", "SOUTH", "NORTH_EAST", "SOUTH_EAST", "NORTH_WEST", "SOUTH_WEST"]>>;
        status: z.ZodDefault<z.ZodEnum<["AVAILABLE", "RESERVED", "SOLD"]>>;
        notes: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
    }, "strip", z.ZodTypeAny, {
        status: "SOLD" | "RESERVED" | "AVAILABLE";
        projectId: number;
        notes: string | null;
        tower: string;
        floor: number;
        unit: string;
        unitType: "2BHK" | "3BHK" | "1BHK" | "4BHK" | "PENTHOUSE" | "SHOP" | "OFFICE" | "PLOT";
        sizeSqft: number;
        price: number;
        facing: "EAST" | "WEST" | "NORTH" | "SOUTH" | "NORTH_EAST" | "SOUTH_WEST" | "SOUTH_EAST" | "NORTH_WEST";
    }, {
        projectId: number;
        tower: string;
        floor: number;
        unit: string;
        status?: "SOLD" | "RESERVED" | "AVAILABLE" | undefined;
        notes?: string | null | undefined;
        unitType?: "2BHK" | "3BHK" | "1BHK" | "4BHK" | "PENTHOUSE" | "SHOP" | "OFFICE" | "PLOT" | undefined;
        sizeSqft?: number | undefined;
        price?: number | undefined;
        facing?: "EAST" | "WEST" | "NORTH" | "SOUTH" | "NORTH_EAST" | "SOUTH_WEST" | "SOUTH_EAST" | "NORTH_WEST" | undefined;
    }>, "many">;
}, "strip", z.ZodTypeAny, {
    rows: {
        status: "SOLD" | "RESERVED" | "AVAILABLE";
        projectId: number;
        notes: string | null;
        tower: string;
        floor: number;
        unit: string;
        unitType: "2BHK" | "3BHK" | "1BHK" | "4BHK" | "PENTHOUSE" | "SHOP" | "OFFICE" | "PLOT";
        sizeSqft: number;
        price: number;
        facing: "EAST" | "WEST" | "NORTH" | "SOUTH" | "NORTH_EAST" | "SOUTH_WEST" | "SOUTH_EAST" | "NORTH_WEST";
    }[];
}, {
    rows: {
        projectId: number;
        tower: string;
        floor: number;
        unit: string;
        status?: "SOLD" | "RESERVED" | "AVAILABLE" | undefined;
        notes?: string | null | undefined;
        unitType?: "2BHK" | "3BHK" | "1BHK" | "4BHK" | "PENTHOUSE" | "SHOP" | "OFFICE" | "PLOT" | undefined;
        sizeSqft?: number | undefined;
        price?: number | undefined;
        facing?: "EAST" | "WEST" | "NORTH" | "SOUTH" | "NORTH_EAST" | "SOUTH_WEST" | "SOUTH_EAST" | "NORTH_WEST" | undefined;
    }[];
}>;
export declare const materialSchema: z.ZodObject<{
    name: z.ZodString;
    category: z.ZodDefault<z.ZodEnum<["CEMENT", "SAND", "STEEL", "BRICKS", "GRAVEL", "PAINT", "PIPES", "ELECTRICAL", "GENERAL"]>>;
    unit: z.ZodString;
    openingStock: z.ZodDefault<z.ZodNumber>;
    reorderLevel: z.ZodDefault<z.ZodNumber>;
    rate: z.ZodDefault<z.ZodNumber>;
    active: z.ZodDefault<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    name: string;
    unit: string;
    category: "CEMENT" | "SAND" | "STEEL" | "BRICKS" | "GRAVEL" | "PAINT" | "PIPES" | "ELECTRICAL" | "GENERAL";
    openingStock: number;
    reorderLevel: number;
    rate: number;
    active: boolean;
}, {
    name: string;
    unit: string;
    category?: "CEMENT" | "SAND" | "STEEL" | "BRICKS" | "GRAVEL" | "PAINT" | "PIPES" | "ELECTRICAL" | "GENERAL" | undefined;
    openingStock?: number | undefined;
    reorderLevel?: number | undefined;
    rate?: number | undefined;
    active?: boolean | undefined;
}>;
export declare const purchaseSchema: z.ZodObject<{
    materialId: z.ZodNumber;
    projectId: z.ZodNullable<z.ZodOptional<z.ZodNumber>>;
    quantity: z.ZodEffects<z.ZodNumber, number, number>;
    rate: z.ZodNumber;
    supplier: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
    invoiceNo: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
    purchasedOn: z.ZodEffects<z.ZodEffects<z.ZodUnion<[z.ZodString, z.ZodDate]>, Date, string | Date>, Date, string | Date>;
    notes: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
}, "strip", z.ZodTypeAny, {
    notes: string | null;
    rate: number;
    quantity: number;
    supplier: string | null;
    invoiceNo: string | null;
    purchasedOn: Date;
    materialId: number;
    projectId?: number | null | undefined;
}, {
    rate: number;
    quantity: number;
    purchasedOn: string | Date;
    materialId: number;
    projectId?: number | null | undefined;
    notes?: string | null | undefined;
    supplier?: string | null | undefined;
    invoiceNo?: string | null | undefined;
}>;
export declare const materialUsageSchema: z.ZodObject<{
    materialId: z.ZodNumber;
    projectId: z.ZodNumber;
    quantity: z.ZodEffects<z.ZodNumber, number, number>;
    usedOn: z.ZodEffects<z.ZodEffects<z.ZodUnion<[z.ZodString, z.ZodDate]>, Date, string | Date>, Date, string | Date>;
    issuedTo: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
    notes: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
}, "strip", z.ZodTypeAny, {
    projectId: number;
    notes: string | null;
    quantity: number;
    materialId: number;
    usedOn: Date;
    issuedTo: string | null;
}, {
    projectId: number;
    quantity: number;
    materialId: number;
    usedOn: string | Date;
    notes?: string | null | undefined;
    issuedTo?: string | null | undefined;
}>;
export declare const stockAdjustmentSchema: z.ZodObject<{
    materialId: z.ZodNumber;
    quantity: z.ZodEffects<z.ZodNumber, number, number>;
    reason: z.ZodDefault<z.ZodEnum<["RETURN", "DAMAGE", "WASTAGE", "CORRECTION"]>>;
    adjustedOn: z.ZodEffects<z.ZodEffects<z.ZodUnion<[z.ZodString, z.ZodDate]>, Date, string | Date>, Date, string | Date>;
    notes: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
}, "strip", z.ZodTypeAny, {
    notes: string | null;
    quantity: number;
    materialId: number;
    reason: "DAMAGE" | "WASTAGE" | "RETURN" | "CORRECTION";
    adjustedOn: Date;
}, {
    quantity: number;
    materialId: number;
    adjustedOn: string | Date;
    notes?: string | null | undefined;
    reason?: "DAMAGE" | "WASTAGE" | "RETURN" | "CORRECTION" | undefined;
}>;
export declare const workerSchema: z.ZodObject<{
    name: z.ZodString;
    mobile: z.ZodEffects<z.ZodUnion<[z.ZodNullable<z.ZodOptional<z.ZodString>>, z.ZodLiteral<"">]>, string | null, string | null | undefined>;
    skill: z.ZodDefault<z.ZodEnum<["MASON", "CARPENTER", "ELECTRICIAN", "PLUMBER", "PAINTER", "HELPER", "OPERATOR", "SUPERVISOR"]>>;
    contractor: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
    dailyWage: z.ZodDefault<z.ZodNumber>;
    projectId: z.ZodNullable<z.ZodOptional<z.ZodNumber>>;
    active: z.ZodDefault<z.ZodBoolean>;
    joinedOn: z.ZodDefault<z.ZodEffects<z.ZodEffects<z.ZodUnion<[z.ZodString, z.ZodDate]>, Date, string | Date>, Date, string | Date>>;
}, "strip", z.ZodTypeAny, {
    name: string;
    contractor: string | null;
    active: boolean;
    mobile: string | null;
    skill: "MASON" | "CARPENTER" | "ELECTRICIAN" | "PLUMBER" | "PAINTER" | "HELPER" | "OPERATOR" | "SUPERVISOR";
    dailyWage: number;
    joinedOn: Date;
    projectId?: number | null | undefined;
}, {
    name: string;
    contractor?: string | null | undefined;
    projectId?: number | null | undefined;
    active?: boolean | undefined;
    mobile?: string | null | undefined;
    skill?: "MASON" | "CARPENTER" | "ELECTRICIAN" | "PLUMBER" | "PAINTER" | "HELPER" | "OPERATOR" | "SUPERVISOR" | undefined;
    dailyWage?: number | undefined;
    joinedOn?: string | Date | undefined;
}>;
export declare const attendanceEntrySchema: z.ZodObject<{
    workerId: z.ZodNumber;
    status: z.ZodDefault<z.ZodEnum<["PRESENT", "HALF_DAY", "ABSENT"]>>;
    overtimeHours: z.ZodDefault<z.ZodNumber>;
    notes: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
}, "strip", z.ZodTypeAny, {
    status: "PRESENT" | "HALF_DAY" | "ABSENT";
    notes: string | null;
    overtimeHours: number;
    workerId: number;
}, {
    workerId: number;
    status?: "PRESENT" | "HALF_DAY" | "ABSENT" | undefined;
    notes?: string | null | undefined;
    overtimeHours?: number | undefined;
}>;
/** The attendance screen saves a whole day for a site in one request. */
export declare const attendanceDaySchema: z.ZodObject<{
    markedOn: z.ZodEffects<z.ZodEffects<z.ZodUnion<[z.ZodString, z.ZodDate]>, Date, string | Date>, Date, string | Date>;
    projectId: z.ZodNullable<z.ZodOptional<z.ZodNumber>>;
    entries: z.ZodArray<z.ZodObject<{
        workerId: z.ZodNumber;
        status: z.ZodDefault<z.ZodEnum<["PRESENT", "HALF_DAY", "ABSENT"]>>;
        overtimeHours: z.ZodDefault<z.ZodNumber>;
        notes: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
    }, "strip", z.ZodTypeAny, {
        status: "PRESENT" | "HALF_DAY" | "ABSENT";
        notes: string | null;
        overtimeHours: number;
        workerId: number;
    }, {
        workerId: number;
        status?: "PRESENT" | "HALF_DAY" | "ABSENT" | undefined;
        notes?: string | null | undefined;
        overtimeHours?: number | undefined;
    }>, "many">;
}, "strip", z.ZodTypeAny, {
    entries: {
        status: "PRESENT" | "HALF_DAY" | "ABSENT";
        notes: string | null;
        overtimeHours: number;
        workerId: number;
    }[];
    markedOn: Date;
    projectId?: number | null | undefined;
}, {
    entries: {
        workerId: number;
        status?: "PRESENT" | "HALF_DAY" | "ABSENT" | undefined;
        notes?: string | null | undefined;
        overtimeHours?: number | undefined;
    }[];
    markedOn: string | Date;
    projectId?: number | null | undefined;
}>;
export declare const dprMaterialSchema: z.ZodObject<{
    materialId: z.ZodNumber;
    quantity: z.ZodEffects<z.ZodNumber, number, number>;
}, "strip", z.ZodTypeAny, {
    quantity: number;
    materialId: number;
}, {
    quantity: number;
    materialId: number;
}>;
export declare const dprSchema: z.ZodObject<{
    projectId: z.ZodNumber;
    reportDate: z.ZodEffects<z.ZodEffects<z.ZodUnion<[z.ZodString, z.ZodDate]>, Date, string | Date>, Date, string | Date>;
    weather: z.ZodDefault<z.ZodEnum<["CLEAR", "CLOUDY", "RAIN", "STORM", "HOT"]>>;
    workCompleted: z.ZodString;
    labourCount: z.ZodDefault<z.ZodNumber>;
    machinery: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
    siteIssues: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
    safetyNotes: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
    preparedBy: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
    materials: z.ZodDefault<z.ZodArray<z.ZodObject<{
        materialId: z.ZodNumber;
        quantity: z.ZodEffects<z.ZodNumber, number, number>;
    }, "strip", z.ZodTypeAny, {
        quantity: number;
        materialId: number;
    }, {
        quantity: number;
        materialId: number;
    }>, "many">>;
    /** When true the materials listed are also booked out of stock. */
    deductStock: z.ZodDefault<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    projectId: number;
    reportDate: Date;
    weather: "CLEAR" | "CLOUDY" | "RAIN" | "HOT" | "STORM";
    workCompleted: string;
    labourCount: number;
    machinery: string | null;
    siteIssues: string | null;
    safetyNotes: string | null;
    preparedBy: string | null;
    materials: {
        quantity: number;
        materialId: number;
    }[];
    deductStock: boolean;
}, {
    projectId: number;
    reportDate: string | Date;
    workCompleted: string;
    weather?: "CLEAR" | "CLOUDY" | "RAIN" | "HOT" | "STORM" | undefined;
    labourCount?: number | undefined;
    machinery?: string | null | undefined;
    siteIssues?: string | null | undefined;
    safetyNotes?: string | null | undefined;
    preparedBy?: string | null | undefined;
    materials?: {
        quantity: number;
        materialId: number;
    }[] | undefined;
    deductStock?: boolean | undefined;
}>;
export declare const settingsSchema: z.ZodObject<{
    companyName: z.ZodString;
    companyAddress: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
    companyPhone: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
    companyEmail: z.ZodEffects<z.ZodUnion<[z.ZodNullable<z.ZodOptional<z.ZodString>>, z.ZodLiteral<"">]>, string | null, string | null | undefined>;
    gstNo: z.ZodEffects<z.ZodNullable<z.ZodOptional<z.ZodString>>, string | null, string | null | undefined>;
    currency: z.ZodDefault<z.ZodString>;
    financialYearStart: z.ZodDefault<z.ZodString>;
    lowStockAlerts: z.ZodDefault<z.ZodBoolean>;
    followUpReminderDays: z.ZodDefault<z.ZodNumber>;
}, "strip", z.ZodTypeAny, {
    companyName: string;
    companyAddress: string | null;
    companyPhone: string | null;
    companyEmail: string | null;
    gstNo: string | null;
    currency: string;
    financialYearStart: string;
    lowStockAlerts: boolean;
    followUpReminderDays: number;
}, {
    companyName: string;
    companyAddress?: string | null | undefined;
    companyPhone?: string | null | undefined;
    companyEmail?: string | null | undefined;
    gstNo?: string | null | undefined;
    currency?: string | undefined;
    financialYearStart?: string | undefined;
    lowStockAlerts?: boolean | undefined;
    followUpReminderDays?: number | undefined;
}>;
export declare const listQuerySchema: z.ZodObject<{
    q: z.ZodOptional<z.ZodString>;
    page: z.ZodDefault<z.ZodNumber>;
    pageSize: z.ZodDefault<z.ZodNumber>;
    sortBy: z.ZodOptional<z.ZodString>;
    sortDir: z.ZodDefault<z.ZodEnum<["asc", "desc"]>>;
    from: z.ZodOptional<z.ZodDate>;
    to: z.ZodOptional<z.ZodDate>;
    status: z.ZodOptional<z.ZodString>;
    projectId: z.ZodOptional<z.ZodNumber>;
    materialId: z.ZodOptional<z.ZodNumber>;
    clientId: z.ZodOptional<z.ZodNumber>;
    workerId: z.ZodOptional<z.ZodNumber>;
    category: z.ZodOptional<z.ZodString>;
    skill: z.ZodOptional<z.ZodString>;
    source: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    page: number;
    pageSize: number;
    sortDir: "asc" | "desc";
    status?: string | undefined;
    projectId?: number | undefined;
    clientId?: number | undefined;
    source?: string | undefined;
    category?: string | undefined;
    materialId?: number | undefined;
    skill?: string | undefined;
    workerId?: number | undefined;
    q?: string | undefined;
    sortBy?: string | undefined;
    from?: Date | undefined;
    to?: Date | undefined;
}, {
    status?: string | undefined;
    projectId?: number | undefined;
    clientId?: number | undefined;
    source?: string | undefined;
    category?: string | undefined;
    materialId?: number | undefined;
    skill?: string | undefined;
    workerId?: number | undefined;
    q?: string | undefined;
    page?: number | undefined;
    pageSize?: number | undefined;
    sortBy?: string | undefined;
    sortDir?: "asc" | "desc" | undefined;
    from?: Date | undefined;
    to?: Date | undefined;
}>;
export type ListQuery = z.infer<typeof listQuerySchema>;
export type LoginInput = z.infer<typeof loginSchema>;
export type ChangePasswordInput = z.infer<typeof changePasswordSchema>;
export type LeadInput = z.input<typeof leadSchema>;
export type ClientInput = z.input<typeof clientSchema>;
export type ProjectInput = z.input<typeof projectSchema>;
export type PropertyInput = z.input<typeof propertySchema>;
export type MaterialInput = z.input<typeof materialSchema>;
export type PurchaseInput = z.input<typeof purchaseSchema>;
export type MaterialUsageInput = z.input<typeof materialUsageSchema>;
export type StockAdjustmentInput = z.input<typeof stockAdjustmentSchema>;
export type WorkerInput = z.input<typeof workerSchema>;
export type DprInput = z.input<typeof dprSchema>;
export type BookingInput = z.input<typeof bookingSchema>;
export type PaymentInput = z.input<typeof paymentSchema>;
export type MilestoneInput = z.input<typeof milestoneSchema>;
export type SettingsInput = z.input<typeof settingsSchema>;
